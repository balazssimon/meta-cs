using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MetaDslx.Compiler.Core.Diagnostics;
using MetaDslx.Compiler.Core.Syntax;
using MetaDslx.Compiler.Core.Syntax.InternalSyntax;

namespace MetaDslx.Languages.Calculator.Syntax.InternalSyntax
{
    public abstract class CalculatorGreenNode : GreenNode
    {
        public CalculatorGreenNode(CalculatorSyntaxKind kind, ImmutableList<DiagnosticInfo> diagnostics, ImmutableList<SyntaxAnnotation> annotations)
            : base((int)kind, 0, diagnostics, annotations)
        {
        }

        public CalculatorSyntaxKind Kind
        {
            get { return (CalculatorSyntaxKind)base.RawKind; }
        }

        public override Language Language
        {
            get { return CalculatorLanguage.Instance; }
        }


        public override TResult Accept<TResult>(InternalSyntaxVisitor<TResult> visitor)
        {
            CalculatorGreenSyntaxVisitor<TResult> typedVisitor = visitor as CalculatorGreenSyntaxVisitor<TResult>;
            if (typedVisitor != null)
            {
                return this.Accept(typedVisitor);
            }
            return default(TResult);
        }

        public abstract TResult Accept<TResult>(CalculatorGreenSyntaxVisitor<TResult> visitor);

        public override void Accept(InternalSyntaxVisitor visitor)
        {
            CalculatorGreenSyntaxVisitor typedVisitor = visitor as CalculatorGreenSyntaxVisitor;
            if (typedVisitor != null)
            {
                this.Accept(typedVisitor);
            }
        }

        public abstract void Accept(CalculatorGreenSyntaxVisitor visitor);
    }

    public abstract class CalculatorGreenSyntaxTrivia : InternalSyntaxTrivia
    {
        public CalculatorGreenSyntaxTrivia(CalculatorSyntaxKind kind, ImmutableList<DiagnosticInfo> diagnostics, ImmutableList<SyntaxAnnotation> annotations)
            : base((int)kind, 0, diagnostics, annotations)
        {
        }

        public CalculatorSyntaxKind Kind
        {
            get { return (CalculatorSyntaxKind)base.RawKind; }
        }

        public override Language Language
        {
            get { return CalculatorLanguage.Instance; }
        }

        public override TResult Accept<TResult>(InternalSyntaxVisitor<TResult> visitor)
        {
            CalculatorGreenSyntaxVisitor<TResult> typedVisitor = visitor as CalculatorGreenSyntaxVisitor<TResult>;
            if (typedVisitor != null)
            {
                return this.Accept(typedVisitor);
            }
            return default(TResult);
        }

        public abstract TResult Accept<TResult>(CalculatorGreenSyntaxVisitor<TResult> visitor);

        public override void Accept(InternalSyntaxVisitor visitor)
        {
            CalculatorGreenSyntaxVisitor typedVisitor = visitor as CalculatorGreenSyntaxVisitor;
            if (typedVisitor != null)
            {
                this.Accept(typedVisitor);
            }
        }

        public abstract void Accept(CalculatorGreenSyntaxVisitor visitor);
    }
	
	public class MainGreen : CalculatorGreenNode, ICompilationUnitInternalSyntax
	{
	    private StatementLineGreen statementLine;
	    private InternalSyntaxToken endOfFileToken;
	
	    public MainGreen(CalculatorSyntaxKind kind, StatementLineGreen statementLine, InternalSyntaxToken endOfFileToken)
	        : base(kind, ImmutableList<DiagnosticInfo>.Empty, ImmutableList<SyntaxAnnotation>.Empty)
	    {
			if (statementLine != null)
			{
				this.AdjustFlagsAndWidth(statementLine);
				this.statementLine = statementLine;
			}
			if (endOfFileToken != null)
			{
				this.AdjustFlagsAndWidth(endOfFileToken);
				this.endOfFileToken = endOfFileToken;
			}
	    }
	
	    public MainGreen(CalculatorSyntaxKind kind, StatementLineGreen statementLine, InternalSyntaxToken endOfFileToken, ImmutableList<DiagnosticInfo> diagnostics, ImmutableList<SyntaxAnnotation> annotations)
	        : base(kind, diagnostics, annotations)
	    {
			if (statementLine != null)
			{
				this.AdjustFlagsAndWidth(statementLine);
				this.statementLine = statementLine;
			}
			if (endOfFileToken != null)
			{
				this.AdjustFlagsAndWidth(endOfFileToken);
				this.endOfFileToken = endOfFileToken;
			}
	    }
	
	    public StatementLineGreen StatementLine { get { return this.statementLine; } }
	    public InternalSyntaxToken EndOfFileToken { get { return this.endOfFileToken; } }
	
	    public override SyntaxNode CreateRed(SyntaxNode parent, int position)
	    {
	        return new global::MetaDslx.Languages.Calculator.Syntax.MainSyntax(this, parent, position);
	    }
	
	    public override int SlotCount
	    {
	        get { return 2; }
	    }
	
	    public override GreenNode GetSlot(int index)
	    {
	        switch (index)
	        {
	            case 0: return this.statementLine;
	            case 1: return this.endOfFileToken;
	            default: return null;
	        }
	    }
	
	    public override GreenNode WithDiagnostics(ImmutableList<DiagnosticInfo> diagnostics)
	    {
	        return new MainGreen(this.Kind, this.statementLine, this.endOfFileToken, diagnostics, this.Annotations);
	    }
	
	    public override GreenNode WithAnnotations(ImmutableList<SyntaxAnnotation> annotations)
	    {
	        return new MainGreen(this.Kind, this.statementLine, this.endOfFileToken, this.Diagnostics, annotations);
	    }
	
	    public MainGreen Update(StatementLineGreen statementLine, InternalSyntaxToken endOfFileToken)
	    {
	        if (this.statementLine != statementLine ||
				this.endOfFileToken != endOfFileToken)
	        {
	            GreenNode newNode = CalculatorGreenFactory.Main(statementLine, endOfFileToken);
	            var diags = this.Diagnostics;
	            if (diags != null && diags.Count > 0)
	               newNode = newNode.WithDiagnostics(diags);
	            var annotations = this.Annotations;
	            if (annotations != null && annotations.Count > 0)
	               newNode = newNode.WithAnnotations(annotations);
				return (MainGreen)newNode;
	        }
	        return this;
	    }
	
	    public override TResult Accept<TResult>(CalculatorGreenSyntaxVisitor<TResult> visitor)
	    {
	        return visitor.Visit(this);
	    }
	
	    public override void Accept(CalculatorGreenSyntaxVisitor visitor)
	    {
	        visitor.Visit(this);
	    }
	}
	
	public class StatementLineGreen : CalculatorGreenNode
	{
	    private StatementGreen statement;
	    private InternalSyntaxToken tSemicolon;
	
	    public StatementLineGreen(CalculatorSyntaxKind kind, StatementGreen statement, InternalSyntaxToken tSemicolon)
	        : base(kind, ImmutableList<DiagnosticInfo>.Empty, ImmutableList<SyntaxAnnotation>.Empty)
	    {
			if (statement != null)
			{
				this.AdjustFlagsAndWidth(statement);
				this.statement = statement;
			}
			if (tSemicolon != null)
			{
				this.AdjustFlagsAndWidth(tSemicolon);
				this.tSemicolon = tSemicolon;
			}
	    }
	
	    public StatementLineGreen(CalculatorSyntaxKind kind, StatementGreen statement, InternalSyntaxToken tSemicolon, ImmutableList<DiagnosticInfo> diagnostics, ImmutableList<SyntaxAnnotation> annotations)
	        : base(kind, diagnostics, annotations)
	    {
			if (statement != null)
			{
				this.AdjustFlagsAndWidth(statement);
				this.statement = statement;
			}
			if (tSemicolon != null)
			{
				this.AdjustFlagsAndWidth(tSemicolon);
				this.tSemicolon = tSemicolon;
			}
	    }
	
	    public StatementGreen Statement { get { return this.statement; } }
	    public InternalSyntaxToken TSemicolon { get { return this.tSemicolon; } }
	
	    public override SyntaxNode CreateRed(SyntaxNode parent, int position)
	    {
	        return new global::MetaDslx.Languages.Calculator.Syntax.StatementLineSyntax(this, parent, position);
	    }
	
	    public override int SlotCount
	    {
	        get { return 2; }
	    }
	
	    public override GreenNode GetSlot(int index)
	    {
	        switch (index)
	        {
	            case 0: return this.statement;
	            case 1: return this.tSemicolon;
	            default: return null;
	        }
	    }
	
	    public override GreenNode WithDiagnostics(ImmutableList<DiagnosticInfo> diagnostics)
	    {
	        return new StatementLineGreen(this.Kind, this.statement, this.tSemicolon, diagnostics, this.Annotations);
	    }
	
	    public override GreenNode WithAnnotations(ImmutableList<SyntaxAnnotation> annotations)
	    {
	        return new StatementLineGreen(this.Kind, this.statement, this.tSemicolon, this.Diagnostics, annotations);
	    }
	
	    public StatementLineGreen Update(StatementGreen statement, InternalSyntaxToken tSemicolon)
	    {
	        if (this.statement != statement ||
				this.tSemicolon != tSemicolon)
	        {
	            GreenNode newNode = CalculatorGreenFactory.StatementLine(statement, tSemicolon);
	            var diags = this.Diagnostics;
	            if (diags != null && diags.Count > 0)
	               newNode = newNode.WithDiagnostics(diags);
	            var annotations = this.Annotations;
	            if (annotations != null && annotations.Count > 0)
	               newNode = newNode.WithAnnotations(annotations);
				return (StatementLineGreen)newNode;
	        }
	        return this;
	    }
	
	    public override TResult Accept<TResult>(CalculatorGreenSyntaxVisitor<TResult> visitor)
	    {
	        return visitor.Visit(this);
	    }
	
	    public override void Accept(CalculatorGreenSyntaxVisitor visitor)
	    {
	        visitor.Visit(this);
	    }
	}
	
	public class StatementGreen : CalculatorGreenNode
	{
	    private AssignmentGreen assignment;
	    private ExpressionGreen expression;
	
	    public StatementGreen(CalculatorSyntaxKind kind, AssignmentGreen assignment, ExpressionGreen expression)
	        : base(kind, ImmutableList<DiagnosticInfo>.Empty, ImmutableList<SyntaxAnnotation>.Empty)
	    {
			if (assignment != null)
			{
				this.AdjustFlagsAndWidth(assignment);
				this.assignment = assignment;
			}
			if (expression != null)
			{
				this.AdjustFlagsAndWidth(expression);
				this.expression = expression;
			}
	    }
	
	    public StatementGreen(CalculatorSyntaxKind kind, AssignmentGreen assignment, ExpressionGreen expression, ImmutableList<DiagnosticInfo> diagnostics, ImmutableList<SyntaxAnnotation> annotations)
	        : base(kind, diagnostics, annotations)
	    {
			if (assignment != null)
			{
				this.AdjustFlagsAndWidth(assignment);
				this.assignment = assignment;
			}
			if (expression != null)
			{
				this.AdjustFlagsAndWidth(expression);
				this.expression = expression;
			}
	    }
	
	    public AssignmentGreen Assignment { get { return this.assignment; } }
	    public ExpressionGreen Expression { get { return this.expression; } }
	
	    public override SyntaxNode CreateRed(SyntaxNode parent, int position)
	    {
	        return new global::MetaDslx.Languages.Calculator.Syntax.StatementSyntax(this, parent, position);
	    }
	
	    public override int SlotCount
	    {
	        get { return 2; }
	    }
	
	    public override GreenNode GetSlot(int index)
	    {
	        switch (index)
	        {
	            case 0: return this.assignment;
	            case 1: return this.expression;
	            default: return null;
	        }
	    }
	
	    public override GreenNode WithDiagnostics(ImmutableList<DiagnosticInfo> diagnostics)
	    {
	        return new StatementGreen(this.Kind, this.assignment, this.expression, diagnostics, this.Annotations);
	    }
	
	    public override GreenNode WithAnnotations(ImmutableList<SyntaxAnnotation> annotations)
	    {
	        return new StatementGreen(this.Kind, this.assignment, this.expression, this.Diagnostics, annotations);
	    }
	
	    public StatementGreen Update(AssignmentGreen assignment, ExpressionGreen expression)
	    {
	        if (this.assignment != assignment ||
				this.expression != expression)
	        {
	            GreenNode newNode = CalculatorGreenFactory.Statement(assignment, expression);
	            var diags = this.Diagnostics;
	            if (diags != null && diags.Count > 0)
	               newNode = newNode.WithDiagnostics(diags);
	            var annotations = this.Annotations;
	            if (annotations != null && annotations.Count > 0)
	               newNode = newNode.WithAnnotations(annotations);
				return (StatementGreen)newNode;
	        }
	        return this;
	    }
	
	    public override TResult Accept<TResult>(CalculatorGreenSyntaxVisitor<TResult> visitor)
	    {
	        return visitor.Visit(this);
	    }
	
	    public override void Accept(CalculatorGreenSyntaxVisitor visitor)
	    {
	        visitor.Visit(this);
	    }
	}
	
	public class AssignmentGreen : CalculatorGreenNode
	{
	    private IdentifierGreen identifier;
	    private InternalSyntaxToken tAssign;
	    private ExpressionGreen expression;
	
	    public AssignmentGreen(CalculatorSyntaxKind kind, IdentifierGreen identifier, InternalSyntaxToken tAssign, ExpressionGreen expression)
	        : base(kind, ImmutableList<DiagnosticInfo>.Empty, ImmutableList<SyntaxAnnotation>.Empty)
	    {
			if (identifier != null)
			{
				this.AdjustFlagsAndWidth(identifier);
				this.identifier = identifier;
			}
			if (tAssign != null)
			{
				this.AdjustFlagsAndWidth(tAssign);
				this.tAssign = tAssign;
			}
			if (expression != null)
			{
				this.AdjustFlagsAndWidth(expression);
				this.expression = expression;
			}
	    }
	
	    public AssignmentGreen(CalculatorSyntaxKind kind, IdentifierGreen identifier, InternalSyntaxToken tAssign, ExpressionGreen expression, ImmutableList<DiagnosticInfo> diagnostics, ImmutableList<SyntaxAnnotation> annotations)
	        : base(kind, diagnostics, annotations)
	    {
			if (identifier != null)
			{
				this.AdjustFlagsAndWidth(identifier);
				this.identifier = identifier;
			}
			if (tAssign != null)
			{
				this.AdjustFlagsAndWidth(tAssign);
				this.tAssign = tAssign;
			}
			if (expression != null)
			{
				this.AdjustFlagsAndWidth(expression);
				this.expression = expression;
			}
	    }
	
	    public IdentifierGreen Identifier { get { return this.identifier; } }
	    public InternalSyntaxToken TAssign { get { return this.tAssign; } }
	    public ExpressionGreen Expression { get { return this.expression; } }
	
	    public override SyntaxNode CreateRed(SyntaxNode parent, int position)
	    {
	        return new global::MetaDslx.Languages.Calculator.Syntax.AssignmentSyntax(this, parent, position);
	    }
	
	    public override int SlotCount
	    {
	        get { return 3; }
	    }
	
	    public override GreenNode GetSlot(int index)
	    {
	        switch (index)
	        {
	            case 0: return this.identifier;
	            case 1: return this.tAssign;
	            case 2: return this.expression;
	            default: return null;
	        }
	    }
	
	    public override GreenNode WithDiagnostics(ImmutableList<DiagnosticInfo> diagnostics)
	    {
	        return new AssignmentGreen(this.Kind, this.identifier, this.tAssign, this.expression, diagnostics, this.Annotations);
	    }
	
	    public override GreenNode WithAnnotations(ImmutableList<SyntaxAnnotation> annotations)
	    {
	        return new AssignmentGreen(this.Kind, this.identifier, this.tAssign, this.expression, this.Diagnostics, annotations);
	    }
	
	    public AssignmentGreen Update(IdentifierGreen identifier, InternalSyntaxToken tAssign, ExpressionGreen expression)
	    {
	        if (this.identifier != identifier ||
				this.tAssign != tAssign ||
				this.expression != expression)
	        {
	            GreenNode newNode = CalculatorGreenFactory.Assignment(identifier, tAssign, expression);
	            var diags = this.Diagnostics;
	            if (diags != null && diags.Count > 0)
	               newNode = newNode.WithDiagnostics(diags);
	            var annotations = this.Annotations;
	            if (annotations != null && annotations.Count > 0)
	               newNode = newNode.WithAnnotations(annotations);
				return (AssignmentGreen)newNode;
	        }
	        return this;
	    }
	
	    public override TResult Accept<TResult>(CalculatorGreenSyntaxVisitor<TResult> visitor)
	    {
	        return visitor.Visit(this);
	    }
	
	    public override void Accept(CalculatorGreenSyntaxVisitor visitor)
	    {
	        visitor.Visit(this);
	    }
	}
	
	public abstract class ExpressionGreen : CalculatorGreenNode
	{
	
	    public ExpressionGreen(CalculatorSyntaxKind kind, ImmutableList<DiagnosticInfo> diagnostics, ImmutableList<SyntaxAnnotation> annotations)
	        : base(kind, diagnostics, annotations)
	    {
	    }
	}
	
	public class ParenExpressionGreen : ExpressionGreen
	{
	    private InternalSyntaxToken tOpenParen;
	    private ExpressionGreen expression;
	    private InternalSyntaxToken tCloseParen;
	
	    public ParenExpressionGreen(CalculatorSyntaxKind kind, InternalSyntaxToken tOpenParen, ExpressionGreen expression, InternalSyntaxToken tCloseParen)
	        : base(kind, ImmutableList<DiagnosticInfo>.Empty, ImmutableList<SyntaxAnnotation>.Empty)
	    {
			if (tOpenParen != null)
			{
				this.AdjustFlagsAndWidth(tOpenParen);
				this.tOpenParen = tOpenParen;
			}
			if (expression != null)
			{
				this.AdjustFlagsAndWidth(expression);
				this.expression = expression;
			}
			if (tCloseParen != null)
			{
				this.AdjustFlagsAndWidth(tCloseParen);
				this.tCloseParen = tCloseParen;
			}
	    }
	
	    public ParenExpressionGreen(CalculatorSyntaxKind kind, InternalSyntaxToken tOpenParen, ExpressionGreen expression, InternalSyntaxToken tCloseParen, ImmutableList<DiagnosticInfo> diagnostics, ImmutableList<SyntaxAnnotation> annotations)
	        : base(kind, diagnostics, annotations)
	    {
			if (tOpenParen != null)
			{
				this.AdjustFlagsAndWidth(tOpenParen);
				this.tOpenParen = tOpenParen;
			}
			if (expression != null)
			{
				this.AdjustFlagsAndWidth(expression);
				this.expression = expression;
			}
			if (tCloseParen != null)
			{
				this.AdjustFlagsAndWidth(tCloseParen);
				this.tCloseParen = tCloseParen;
			}
	    }
	
	    public InternalSyntaxToken TOpenParen { get { return this.tOpenParen; } }
	    public ExpressionGreen Expression { get { return this.expression; } }
	    public InternalSyntaxToken TCloseParen { get { return this.tCloseParen; } }
	
	    public override SyntaxNode CreateRed(SyntaxNode parent, int position)
	    {
	        return new global::MetaDslx.Languages.Calculator.Syntax.ParenExpressionSyntax(this, parent, position);
	    }
	
	    public override int SlotCount
	    {
	        get { return 3; }
	    }
	
	    public override GreenNode GetSlot(int index)
	    {
	        switch (index)
	        {
	            case 0: return this.tOpenParen;
	            case 1: return this.expression;
	            case 2: return this.tCloseParen;
	            default: return null;
	        }
	    }
	
	    public override GreenNode WithDiagnostics(ImmutableList<DiagnosticInfo> diagnostics)
	    {
	        return new ParenExpressionGreen(this.Kind, this.tOpenParen, this.expression, this.tCloseParen, diagnostics, this.Annotations);
	    }
	
	    public override GreenNode WithAnnotations(ImmutableList<SyntaxAnnotation> annotations)
	    {
	        return new ParenExpressionGreen(this.Kind, this.tOpenParen, this.expression, this.tCloseParen, this.Diagnostics, annotations);
	    }
	
	    public ParenExpressionGreen Update(InternalSyntaxToken tOpenParen, ExpressionGreen expression, InternalSyntaxToken tCloseParen)
	    {
	        if (this.tOpenParen != tOpenParen ||
				this.expression != expression ||
				this.tCloseParen != tCloseParen)
	        {
	            GreenNode newNode = CalculatorGreenFactory.ParenExpression(tOpenParen, expression, tCloseParen);
	            var diags = this.Diagnostics;
	            if (diags != null && diags.Count > 0)
	               newNode = newNode.WithDiagnostics(diags);
	            var annotations = this.Annotations;
	            if (annotations != null && annotations.Count > 0)
	               newNode = newNode.WithAnnotations(annotations);
				return (ParenExpressionGreen)newNode;
	        }
	        return this;
	    }
	
	    public override TResult Accept<TResult>(CalculatorGreenSyntaxVisitor<TResult> visitor)
	    {
	        return visitor.Visit(this);
	    }
	
	    public override void Accept(CalculatorGreenSyntaxVisitor visitor)
	    {
	        visitor.Visit(this);
	    }
	}
	
	public class MulOrDivExpressionGreen : ExpressionGreen
	{
	    private ExpressionGreen left;
	    private InternalSyntaxToken tMul;
	    private InternalSyntaxToken tDiv;
	    private ExpressionGreen right;
	
	    public MulOrDivExpressionGreen(CalculatorSyntaxKind kind, ExpressionGreen left, InternalSyntaxToken tMul, InternalSyntaxToken tDiv, ExpressionGreen right)
	        : base(kind, ImmutableList<DiagnosticInfo>.Empty, ImmutableList<SyntaxAnnotation>.Empty)
	    {
			if (left != null)
			{
				this.AdjustFlagsAndWidth(left);
				this.left = left;
			}
			if (tMul != null)
			{
				this.AdjustFlagsAndWidth(tMul);
				this.tMul = tMul;
			}
			if (tDiv != null)
			{
				this.AdjustFlagsAndWidth(tDiv);
				this.tDiv = tDiv;
			}
			if (right != null)
			{
				this.AdjustFlagsAndWidth(right);
				this.right = right;
			}
	    }
	
	    public MulOrDivExpressionGreen(CalculatorSyntaxKind kind, ExpressionGreen left, InternalSyntaxToken tMul, InternalSyntaxToken tDiv, ExpressionGreen right, ImmutableList<DiagnosticInfo> diagnostics, ImmutableList<SyntaxAnnotation> annotations)
	        : base(kind, diagnostics, annotations)
	    {
			if (left != null)
			{
				this.AdjustFlagsAndWidth(left);
				this.left = left;
			}
			if (tMul != null)
			{
				this.AdjustFlagsAndWidth(tMul);
				this.tMul = tMul;
			}
			if (tDiv != null)
			{
				this.AdjustFlagsAndWidth(tDiv);
				this.tDiv = tDiv;
			}
			if (right != null)
			{
				this.AdjustFlagsAndWidth(right);
				this.right = right;
			}
	    }
	
	    public ExpressionGreen Left { get { return this.left; } }
	    public InternalSyntaxToken TMul { get { return this.tMul; } }
	    public InternalSyntaxToken TDiv { get { return this.tDiv; } }
	    public ExpressionGreen Right { get { return this.right; } }
	
	    public override SyntaxNode CreateRed(SyntaxNode parent, int position)
	    {
	        return new global::MetaDslx.Languages.Calculator.Syntax.MulOrDivExpressionSyntax(this, parent, position);
	    }
	
	    public override int SlotCount
	    {
	        get { return 4; }
	    }
	
	    public override GreenNode GetSlot(int index)
	    {
	        switch (index)
	        {
	            case 0: return this.left;
	            case 1: return this.tMul;
	            case 2: return this.tDiv;
	            case 3: return this.right;
	            default: return null;
	        }
	    }
	
	    public override GreenNode WithDiagnostics(ImmutableList<DiagnosticInfo> diagnostics)
	    {
	        return new MulOrDivExpressionGreen(this.Kind, this.left, this.tMul, this.tDiv, this.right, diagnostics, this.Annotations);
	    }
	
	    public override GreenNode WithAnnotations(ImmutableList<SyntaxAnnotation> annotations)
	    {
	        return new MulOrDivExpressionGreen(this.Kind, this.left, this.tMul, this.tDiv, this.right, this.Diagnostics, annotations);
	    }
	
	    public MulOrDivExpressionGreen Update(ExpressionGreen left, InternalSyntaxToken tMul, InternalSyntaxToken tDiv, ExpressionGreen right)
	    {
	        if (this.left != left ||
				this.tMul != tMul ||
				this.tDiv != tDiv ||
				this.right != right)
	        {
	            GreenNode newNode = CalculatorGreenFactory.MulOrDivExpression(left, tMul, tDiv, right);
	            var diags = this.Diagnostics;
	            if (diags != null && diags.Count > 0)
	               newNode = newNode.WithDiagnostics(diags);
	            var annotations = this.Annotations;
	            if (annotations != null && annotations.Count > 0)
	               newNode = newNode.WithAnnotations(annotations);
				return (MulOrDivExpressionGreen)newNode;
	        }
	        return this;
	    }
	
	    public override TResult Accept<TResult>(CalculatorGreenSyntaxVisitor<TResult> visitor)
	    {
	        return visitor.Visit(this);
	    }
	
	    public override void Accept(CalculatorGreenSyntaxVisitor visitor)
	    {
	        visitor.Visit(this);
	    }
	}
	
	public class AddOrSubExpressionGreen : ExpressionGreen
	{
	    private ExpressionGreen left;
	    private InternalSyntaxToken tAdd;
	    private InternalSyntaxToken tSub;
	    private ExpressionGreen right;
	
	    public AddOrSubExpressionGreen(CalculatorSyntaxKind kind, ExpressionGreen left, InternalSyntaxToken tAdd, InternalSyntaxToken tSub, ExpressionGreen right)
	        : base(kind, ImmutableList<DiagnosticInfo>.Empty, ImmutableList<SyntaxAnnotation>.Empty)
	    {
			if (left != null)
			{
				this.AdjustFlagsAndWidth(left);
				this.left = left;
			}
			if (tAdd != null)
			{
				this.AdjustFlagsAndWidth(tAdd);
				this.tAdd = tAdd;
			}
			if (tSub != null)
			{
				this.AdjustFlagsAndWidth(tSub);
				this.tSub = tSub;
			}
			if (right != null)
			{
				this.AdjustFlagsAndWidth(right);
				this.right = right;
			}
	    }
	
	    public AddOrSubExpressionGreen(CalculatorSyntaxKind kind, ExpressionGreen left, InternalSyntaxToken tAdd, InternalSyntaxToken tSub, ExpressionGreen right, ImmutableList<DiagnosticInfo> diagnostics, ImmutableList<SyntaxAnnotation> annotations)
	        : base(kind, diagnostics, annotations)
	    {
			if (left != null)
			{
				this.AdjustFlagsAndWidth(left);
				this.left = left;
			}
			if (tAdd != null)
			{
				this.AdjustFlagsAndWidth(tAdd);
				this.tAdd = tAdd;
			}
			if (tSub != null)
			{
				this.AdjustFlagsAndWidth(tSub);
				this.tSub = tSub;
			}
			if (right != null)
			{
				this.AdjustFlagsAndWidth(right);
				this.right = right;
			}
	    }
	
	    public ExpressionGreen Left { get { return this.left; } }
	    public InternalSyntaxToken TAdd { get { return this.tAdd; } }
	    public InternalSyntaxToken TSub { get { return this.tSub; } }
	    public ExpressionGreen Right { get { return this.right; } }
	
	    public override SyntaxNode CreateRed(SyntaxNode parent, int position)
	    {
	        return new global::MetaDslx.Languages.Calculator.Syntax.AddOrSubExpressionSyntax(this, parent, position);
	    }
	
	    public override int SlotCount
	    {
	        get { return 4; }
	    }
	
	    public override GreenNode GetSlot(int index)
	    {
	        switch (index)
	        {
	            case 0: return this.left;
	            case 1: return this.tAdd;
	            case 2: return this.tSub;
	            case 3: return this.right;
	            default: return null;
	        }
	    }
	
	    public override GreenNode WithDiagnostics(ImmutableList<DiagnosticInfo> diagnostics)
	    {
	        return new AddOrSubExpressionGreen(this.Kind, this.left, this.tAdd, this.tSub, this.right, diagnostics, this.Annotations);
	    }
	
	    public override GreenNode WithAnnotations(ImmutableList<SyntaxAnnotation> annotations)
	    {
	        return new AddOrSubExpressionGreen(this.Kind, this.left, this.tAdd, this.tSub, this.right, this.Diagnostics, annotations);
	    }
	
	    public AddOrSubExpressionGreen Update(ExpressionGreen left, InternalSyntaxToken tAdd, InternalSyntaxToken tSub, ExpressionGreen right)
	    {
	        if (this.left != left ||
				this.tAdd != tAdd ||
				this.tSub != tSub ||
				this.right != right)
	        {
	            GreenNode newNode = CalculatorGreenFactory.AddOrSubExpression(left, tAdd, tSub, right);
	            var diags = this.Diagnostics;
	            if (diags != null && diags.Count > 0)
	               newNode = newNode.WithDiagnostics(diags);
	            var annotations = this.Annotations;
	            if (annotations != null && annotations.Count > 0)
	               newNode = newNode.WithAnnotations(annotations);
				return (AddOrSubExpressionGreen)newNode;
	        }
	        return this;
	    }
	
	    public override TResult Accept<TResult>(CalculatorGreenSyntaxVisitor<TResult> visitor)
	    {
	        return visitor.Visit(this);
	    }
	
	    public override void Accept(CalculatorGreenSyntaxVisitor visitor)
	    {
	        visitor.Visit(this);
	    }
	}
	
	public class PrintExpressionGreen : ExpressionGreen
	{
	    private InternalSyntaxToken kPrint;
	    private ArgsGreen args;
	
	    public PrintExpressionGreen(CalculatorSyntaxKind kind, InternalSyntaxToken kPrint, ArgsGreen args)
	        : base(kind, ImmutableList<DiagnosticInfo>.Empty, ImmutableList<SyntaxAnnotation>.Empty)
	    {
			if (kPrint != null)
			{
				this.AdjustFlagsAndWidth(kPrint);
				this.kPrint = kPrint;
			}
			if (args != null)
			{
				this.AdjustFlagsAndWidth(args);
				this.args = args;
			}
	    }
	
	    public PrintExpressionGreen(CalculatorSyntaxKind kind, InternalSyntaxToken kPrint, ArgsGreen args, ImmutableList<DiagnosticInfo> diagnostics, ImmutableList<SyntaxAnnotation> annotations)
	        : base(kind, diagnostics, annotations)
	    {
			if (kPrint != null)
			{
				this.AdjustFlagsAndWidth(kPrint);
				this.kPrint = kPrint;
			}
			if (args != null)
			{
				this.AdjustFlagsAndWidth(args);
				this.args = args;
			}
	    }
	
	    public InternalSyntaxToken KPrint { get { return this.kPrint; } }
	    public ArgsGreen Args { get { return this.args; } }
	
	    public override SyntaxNode CreateRed(SyntaxNode parent, int position)
	    {
	        return new global::MetaDslx.Languages.Calculator.Syntax.PrintExpressionSyntax(this, parent, position);
	    }
	
	    public override int SlotCount
	    {
	        get { return 2; }
	    }
	
	    public override GreenNode GetSlot(int index)
	    {
	        switch (index)
	        {
	            case 0: return this.kPrint;
	            case 1: return this.args;
	            default: return null;
	        }
	    }
	
	    public override GreenNode WithDiagnostics(ImmutableList<DiagnosticInfo> diagnostics)
	    {
	        return new PrintExpressionGreen(this.Kind, this.kPrint, this.args, diagnostics, this.Annotations);
	    }
	
	    public override GreenNode WithAnnotations(ImmutableList<SyntaxAnnotation> annotations)
	    {
	        return new PrintExpressionGreen(this.Kind, this.kPrint, this.args, this.Diagnostics, annotations);
	    }
	
	    public PrintExpressionGreen Update(InternalSyntaxToken kPrint, ArgsGreen args)
	    {
	        if (this.kPrint != kPrint ||
				this.args != args)
	        {
	            GreenNode newNode = CalculatorGreenFactory.PrintExpression(kPrint, args);
	            var diags = this.Diagnostics;
	            if (diags != null && diags.Count > 0)
	               newNode = newNode.WithDiagnostics(diags);
	            var annotations = this.Annotations;
	            if (annotations != null && annotations.Count > 0)
	               newNode = newNode.WithAnnotations(annotations);
				return (PrintExpressionGreen)newNode;
	        }
	        return this;
	    }
	
	    public override TResult Accept<TResult>(CalculatorGreenSyntaxVisitor<TResult> visitor)
	    {
	        return visitor.Visit(this);
	    }
	
	    public override void Accept(CalculatorGreenSyntaxVisitor visitor)
	    {
	        visitor.Visit(this);
	    }
	}
	
	public class ValueExpressionGreen : ExpressionGreen
	{
	    private ValueGreen value;
	
	    public ValueExpressionGreen(CalculatorSyntaxKind kind, ValueGreen value)
	        : base(kind, ImmutableList<DiagnosticInfo>.Empty, ImmutableList<SyntaxAnnotation>.Empty)
	    {
			if (value != null)
			{
				this.AdjustFlagsAndWidth(value);
				this.value = value;
			}
	    }
	
	    public ValueExpressionGreen(CalculatorSyntaxKind kind, ValueGreen value, ImmutableList<DiagnosticInfo> diagnostics, ImmutableList<SyntaxAnnotation> annotations)
	        : base(kind, diagnostics, annotations)
	    {
			if (value != null)
			{
				this.AdjustFlagsAndWidth(value);
				this.value = value;
			}
	    }
	
	    public ValueGreen Value { get { return this.value; } }
	
	    public override SyntaxNode CreateRed(SyntaxNode parent, int position)
	    {
	        return new global::MetaDslx.Languages.Calculator.Syntax.ValueExpressionSyntax(this, parent, position);
	    }
	
	    public override int SlotCount
	    {
	        get { return 1; }
	    }
	
	    public override GreenNode GetSlot(int index)
	    {
	        switch (index)
	        {
	            case 0: return this.value;
	            default: return null;
	        }
	    }
	
	    public override GreenNode WithDiagnostics(ImmutableList<DiagnosticInfo> diagnostics)
	    {
	        return new ValueExpressionGreen(this.Kind, this.value, diagnostics, this.Annotations);
	    }
	
	    public override GreenNode WithAnnotations(ImmutableList<SyntaxAnnotation> annotations)
	    {
	        return new ValueExpressionGreen(this.Kind, this.value, this.Diagnostics, annotations);
	    }
	
	    public ValueExpressionGreen Update(ValueGreen value)
	    {
	        if (this.value != value)
	        {
	            GreenNode newNode = CalculatorGreenFactory.ValueExpression(value);
	            var diags = this.Diagnostics;
	            if (diags != null && diags.Count > 0)
	               newNode = newNode.WithDiagnostics(diags);
	            var annotations = this.Annotations;
	            if (annotations != null && annotations.Count > 0)
	               newNode = newNode.WithAnnotations(annotations);
				return (ValueExpressionGreen)newNode;
	        }
	        return this;
	    }
	
	    public override TResult Accept<TResult>(CalculatorGreenSyntaxVisitor<TResult> visitor)
	    {
	        return visitor.Visit(this);
	    }
	
	    public override void Accept(CalculatorGreenSyntaxVisitor visitor)
	    {
	        visitor.Visit(this);
	    }
	}
	
	public class ArgsGreen : CalculatorGreenNode
	{
	    private InternalSyntaxList<ArgGreen> arg;
	    private InternalSyntaxToken tComma;
	
	    public ArgsGreen(CalculatorSyntaxKind kind, InternalSyntaxList<ArgGreen> arg, InternalSyntaxToken tComma)
	        : base(kind, ImmutableList<DiagnosticInfo>.Empty, ImmutableList<SyntaxAnnotation>.Empty)
	    {
			if (arg != null)
			{
				this.AdjustFlagsAndWidth(arg);
				this.arg = arg;
			}
			if (tComma != null)
			{
				this.AdjustFlagsAndWidth(tComma);
				this.tComma = tComma;
			}
	    }
	
	    public ArgsGreen(CalculatorSyntaxKind kind, InternalSyntaxList<ArgGreen> arg, InternalSyntaxToken tComma, ImmutableList<DiagnosticInfo> diagnostics, ImmutableList<SyntaxAnnotation> annotations)
	        : base(kind, diagnostics, annotations)
	    {
			if (arg != null)
			{
				this.AdjustFlagsAndWidth(arg);
				this.arg = arg;
			}
			if (tComma != null)
			{
				this.AdjustFlagsAndWidth(tComma);
				this.tComma = tComma;
			}
	    }
	
	    public InternalSyntaxList<ArgGreen> Arg { get { return this.arg; } }
	    public InternalSyntaxToken TComma { get { return this.tComma; } }
	
	    public override SyntaxNode CreateRed(SyntaxNode parent, int position)
	    {
	        return new global::MetaDslx.Languages.Calculator.Syntax.ArgsSyntax(this, parent, position);
	    }
	
	    public override int SlotCount
	    {
	        get { return 2; }
	    }
	
	    public override GreenNode GetSlot(int index)
	    {
	        switch (index)
	        {
	            case 0: return this.arg;
	            case 1: return this.tComma;
	            default: return null;
	        }
	    }
	
	    public override GreenNode WithDiagnostics(ImmutableList<DiagnosticInfo> diagnostics)
	    {
	        return new ArgsGreen(this.Kind, this.arg, this.tComma, diagnostics, this.Annotations);
	    }
	
	    public override GreenNode WithAnnotations(ImmutableList<SyntaxAnnotation> annotations)
	    {
	        return new ArgsGreen(this.Kind, this.arg, this.tComma, this.Diagnostics, annotations);
	    }
	
	    public ArgsGreen Update(InternalSyntaxList<ArgGreen> arg, InternalSyntaxToken tComma)
	    {
	        if (this.arg != arg ||
				this.tComma != tComma)
	        {
	            GreenNode newNode = CalculatorGreenFactory.Args(arg, tComma);
	            var diags = this.Diagnostics;
	            if (diags != null && diags.Count > 0)
	               newNode = newNode.WithDiagnostics(diags);
	            var annotations = this.Annotations;
	            if (annotations != null && annotations.Count > 0)
	               newNode = newNode.WithAnnotations(annotations);
				return (ArgsGreen)newNode;
	        }
	        return this;
	    }
	
	    public override TResult Accept<TResult>(CalculatorGreenSyntaxVisitor<TResult> visitor)
	    {
	        return visitor.Visit(this);
	    }
	
	    public override void Accept(CalculatorGreenSyntaxVisitor visitor)
	    {
	        visitor.Visit(this);
	    }
	}
	
	public class ValueGreen : CalculatorGreenNode
	{
	    private IdentifierGreen identifier;
	    private StringGreen _string;
	    private IntegerGreen integer;
	
	    public ValueGreen(CalculatorSyntaxKind kind, IdentifierGreen identifier, StringGreen _string, IntegerGreen integer)
	        : base(kind, ImmutableList<DiagnosticInfo>.Empty, ImmutableList<SyntaxAnnotation>.Empty)
	    {
			if (identifier != null)
			{
				this.AdjustFlagsAndWidth(identifier);
				this.identifier = identifier;
			}
			if (_string != null)
			{
				this.AdjustFlagsAndWidth(_string);
				this._string = _string;
			}
			if (integer != null)
			{
				this.AdjustFlagsAndWidth(integer);
				this.integer = integer;
			}
	    }
	
	    public ValueGreen(CalculatorSyntaxKind kind, IdentifierGreen identifier, StringGreen _string, IntegerGreen integer, ImmutableList<DiagnosticInfo> diagnostics, ImmutableList<SyntaxAnnotation> annotations)
	        : base(kind, diagnostics, annotations)
	    {
			if (identifier != null)
			{
				this.AdjustFlagsAndWidth(identifier);
				this.identifier = identifier;
			}
			if (_string != null)
			{
				this.AdjustFlagsAndWidth(_string);
				this._string = _string;
			}
			if (integer != null)
			{
				this.AdjustFlagsAndWidth(integer);
				this.integer = integer;
			}
	    }
	
	    public IdentifierGreen Identifier { get { return this.identifier; } }
	    public StringGreen String { get { return this._string; } }
	    public IntegerGreen Integer { get { return this.integer; } }
	
	    public override SyntaxNode CreateRed(SyntaxNode parent, int position)
	    {
	        return new global::MetaDslx.Languages.Calculator.Syntax.ValueSyntax(this, parent, position);
	    }
	
	    public override int SlotCount
	    {
	        get { return 3; }
	    }
	
	    public override GreenNode GetSlot(int index)
	    {
	        switch (index)
	        {
	            case 0: return this.identifier;
	            case 1: return this._string;
	            case 2: return this.integer;
	            default: return null;
	        }
	    }
	
	    public override GreenNode WithDiagnostics(ImmutableList<DiagnosticInfo> diagnostics)
	    {
	        return new ValueGreen(this.Kind, this.identifier, this._string, this.integer, diagnostics, this.Annotations);
	    }
	
	    public override GreenNode WithAnnotations(ImmutableList<SyntaxAnnotation> annotations)
	    {
	        return new ValueGreen(this.Kind, this.identifier, this._string, this.integer, this.Diagnostics, annotations);
	    }
	
	    public ValueGreen Update(IdentifierGreen identifier, StringGreen _string, IntegerGreen integer)
	    {
	        if (this.identifier != identifier ||
				this._string != _string ||
				this.integer != integer)
	        {
	            GreenNode newNode = CalculatorGreenFactory.Value(identifier, _string, integer);
	            var diags = this.Diagnostics;
	            if (diags != null && diags.Count > 0)
	               newNode = newNode.WithDiagnostics(diags);
	            var annotations = this.Annotations;
	            if (annotations != null && annotations.Count > 0)
	               newNode = newNode.WithAnnotations(annotations);
				return (ValueGreen)newNode;
	        }
	        return this;
	    }
	
	    public override TResult Accept<TResult>(CalculatorGreenSyntaxVisitor<TResult> visitor)
	    {
	        return visitor.Visit(this);
	    }
	
	    public override void Accept(CalculatorGreenSyntaxVisitor visitor)
	    {
	        visitor.Visit(this);
	    }
	}
	
	public class IdentifierGreen : CalculatorGreenNode
	{
	    private InternalSyntaxToken iD;
	
	    public IdentifierGreen(CalculatorSyntaxKind kind, InternalSyntaxToken iD)
	        : base(kind, ImmutableList<DiagnosticInfo>.Empty, ImmutableList<SyntaxAnnotation>.Empty)
	    {
			if (iD != null)
			{
				this.AdjustFlagsAndWidth(iD);
				this.iD = iD;
			}
	    }
	
	    public IdentifierGreen(CalculatorSyntaxKind kind, InternalSyntaxToken iD, ImmutableList<DiagnosticInfo> diagnostics, ImmutableList<SyntaxAnnotation> annotations)
	        : base(kind, diagnostics, annotations)
	    {
			if (iD != null)
			{
				this.AdjustFlagsAndWidth(iD);
				this.iD = iD;
			}
	    }
	
	    public InternalSyntaxToken ID { get { return this.iD; } }
	
	    public override SyntaxNode CreateRed(SyntaxNode parent, int position)
	    {
	        return new global::MetaDslx.Languages.Calculator.Syntax.IdentifierSyntax(this, parent, position);
	    }
	
	    public override int SlotCount
	    {
	        get { return 1; }
	    }
	
	    public override GreenNode GetSlot(int index)
	    {
	        switch (index)
	        {
	            case 0: return this.iD;
	            default: return null;
	        }
	    }
	
	    public override GreenNode WithDiagnostics(ImmutableList<DiagnosticInfo> diagnostics)
	    {
	        return new IdentifierGreen(this.Kind, this.iD, diagnostics, this.Annotations);
	    }
	
	    public override GreenNode WithAnnotations(ImmutableList<SyntaxAnnotation> annotations)
	    {
	        return new IdentifierGreen(this.Kind, this.iD, this.Diagnostics, annotations);
	    }
	
	    public IdentifierGreen Update(InternalSyntaxToken iD)
	    {
	        if (this.iD != iD)
	        {
	            GreenNode newNode = CalculatorGreenFactory.Identifier(iD);
	            var diags = this.Diagnostics;
	            if (diags != null && diags.Count > 0)
	               newNode = newNode.WithDiagnostics(diags);
	            var annotations = this.Annotations;
	            if (annotations != null && annotations.Count > 0)
	               newNode = newNode.WithAnnotations(annotations);
				return (IdentifierGreen)newNode;
	        }
	        return this;
	    }
	
	    public override TResult Accept<TResult>(CalculatorGreenSyntaxVisitor<TResult> visitor)
	    {
	        return visitor.Visit(this);
	    }
	
	    public override void Accept(CalculatorGreenSyntaxVisitor visitor)
	    {
	        visitor.Visit(this);
	    }
	}
	
	public class StringGreen : CalculatorGreenNode
	{
	    private InternalSyntaxToken sTRING;
	
	    public StringGreen(CalculatorSyntaxKind kind, InternalSyntaxToken sTRING)
	        : base(kind, ImmutableList<DiagnosticInfo>.Empty, ImmutableList<SyntaxAnnotation>.Empty)
	    {
			if (sTRING != null)
			{
				this.AdjustFlagsAndWidth(sTRING);
				this.sTRING = sTRING;
			}
	    }
	
	    public StringGreen(CalculatorSyntaxKind kind, InternalSyntaxToken sTRING, ImmutableList<DiagnosticInfo> diagnostics, ImmutableList<SyntaxAnnotation> annotations)
	        : base(kind, diagnostics, annotations)
	    {
			if (sTRING != null)
			{
				this.AdjustFlagsAndWidth(sTRING);
				this.sTRING = sTRING;
			}
	    }
	
	    public InternalSyntaxToken STRING { get { return this.sTRING; } }
	
	    public override SyntaxNode CreateRed(SyntaxNode parent, int position)
	    {
	        return new global::MetaDslx.Languages.Calculator.Syntax.StringSyntax(this, parent, position);
	    }
	
	    public override int SlotCount
	    {
	        get { return 1; }
	    }
	
	    public override GreenNode GetSlot(int index)
	    {
	        switch (index)
	        {
	            case 0: return this.sTRING;
	            default: return null;
	        }
	    }
	
	    public override GreenNode WithDiagnostics(ImmutableList<DiagnosticInfo> diagnostics)
	    {
	        return new StringGreen(this.Kind, this.sTRING, diagnostics, this.Annotations);
	    }
	
	    public override GreenNode WithAnnotations(ImmutableList<SyntaxAnnotation> annotations)
	    {
	        return new StringGreen(this.Kind, this.sTRING, this.Diagnostics, annotations);
	    }
	
	    public StringGreen Update(InternalSyntaxToken sTRING)
	    {
	        if (this.sTRING != sTRING)
	        {
	            GreenNode newNode = CalculatorGreenFactory.String(sTRING);
	            var diags = this.Diagnostics;
	            if (diags != null && diags.Count > 0)
	               newNode = newNode.WithDiagnostics(diags);
	            var annotations = this.Annotations;
	            if (annotations != null && annotations.Count > 0)
	               newNode = newNode.WithAnnotations(annotations);
				return (StringGreen)newNode;
	        }
	        return this;
	    }
	
	    public override TResult Accept<TResult>(CalculatorGreenSyntaxVisitor<TResult> visitor)
	    {
	        return visitor.Visit(this);
	    }
	
	    public override void Accept(CalculatorGreenSyntaxVisitor visitor)
	    {
	        visitor.Visit(this);
	    }
	}
	
	public class IntegerGreen : CalculatorGreenNode
	{
	    private InternalSyntaxToken iNT;
	
	    public IntegerGreen(CalculatorSyntaxKind kind, InternalSyntaxToken iNT)
	        : base(kind, ImmutableList<DiagnosticInfo>.Empty, ImmutableList<SyntaxAnnotation>.Empty)
	    {
			if (iNT != null)
			{
				this.AdjustFlagsAndWidth(iNT);
				this.iNT = iNT;
			}
	    }
	
	    public IntegerGreen(CalculatorSyntaxKind kind, InternalSyntaxToken iNT, ImmutableList<DiagnosticInfo> diagnostics, ImmutableList<SyntaxAnnotation> annotations)
	        : base(kind, diagnostics, annotations)
	    {
			if (iNT != null)
			{
				this.AdjustFlagsAndWidth(iNT);
				this.iNT = iNT;
			}
	    }
	
	    public InternalSyntaxToken INT { get { return this.iNT; } }
	
	    public override SyntaxNode CreateRed(SyntaxNode parent, int position)
	    {
	        return new global::MetaDslx.Languages.Calculator.Syntax.IntegerSyntax(this, parent, position);
	    }
	
	    public override int SlotCount
	    {
	        get { return 1; }
	    }
	
	    public override GreenNode GetSlot(int index)
	    {
	        switch (index)
	        {
	            case 0: return this.iNT;
	            default: return null;
	        }
	    }
	
	    public override GreenNode WithDiagnostics(ImmutableList<DiagnosticInfo> diagnostics)
	    {
	        return new IntegerGreen(this.Kind, this.iNT, diagnostics, this.Annotations);
	    }
	
	    public override GreenNode WithAnnotations(ImmutableList<SyntaxAnnotation> annotations)
	    {
	        return new IntegerGreen(this.Kind, this.iNT, this.Diagnostics, annotations);
	    }
	
	    public IntegerGreen Update(InternalSyntaxToken iNT)
	    {
	        if (this.iNT != iNT)
	        {
	            GreenNode newNode = CalculatorGreenFactory.Integer(iNT);
	            var diags = this.Diagnostics;
	            if (diags != null && diags.Count > 0)
	               newNode = newNode.WithDiagnostics(diags);
	            var annotations = this.Annotations;
	            if (annotations != null && annotations.Count > 0)
	               newNode = newNode.WithAnnotations(annotations);
				return (IntegerGreen)newNode;
	        }
	        return this;
	    }
	
	    public override TResult Accept<TResult>(CalculatorGreenSyntaxVisitor<TResult> visitor)
	    {
	        return visitor.Visit(this);
	    }
	
	    public override void Accept(CalculatorGreenSyntaxVisitor visitor)
	    {
	        visitor.Visit(this);
	    }
	}
	
	public class ArgGreen : CalculatorGreenNode
	{
	    private ValueGreen value;
	
	    public ArgGreen(CalculatorSyntaxKind kind, ValueGreen value)
	        : base(kind, ImmutableList<DiagnosticInfo>.Empty, ImmutableList<SyntaxAnnotation>.Empty)
	    {
			if (value != null)
			{
				this.AdjustFlagsAndWidth(value);
				this.value = value;
			}
	    }
	
	    public ArgGreen(CalculatorSyntaxKind kind, ValueGreen value, ImmutableList<DiagnosticInfo> diagnostics, ImmutableList<SyntaxAnnotation> annotations)
	        : base(kind, diagnostics, annotations)
	    {
			if (value != null)
			{
				this.AdjustFlagsAndWidth(value);
				this.value = value;
			}
	    }
	
	    public ValueGreen Value { get { return this.value; } }
	
	    public override SyntaxNode CreateRed(SyntaxNode parent, int position)
	    {
	        return new global::MetaDslx.Languages.Calculator.Syntax.ArgSyntax(this, parent, position);
	    }
	
	    public override int SlotCount
	    {
	        get { return 1; }
	    }
	
	    public override GreenNode GetSlot(int index)
	    {
	        switch (index)
	        {
	            case 0: return this.value;
	            default: return null;
	        }
	    }
	
	    public override GreenNode WithDiagnostics(ImmutableList<DiagnosticInfo> diagnostics)
	    {
	        return new ArgGreen(this.Kind, this.value, diagnostics, this.Annotations);
	    }
	
	    public override GreenNode WithAnnotations(ImmutableList<SyntaxAnnotation> annotations)
	    {
	        return new ArgGreen(this.Kind, this.value, this.Diagnostics, annotations);
	    }
	
	    public ArgGreen Update(ValueGreen value)
	    {
	        if (this.value != value)
	        {
	            GreenNode newNode = CalculatorGreenFactory.Arg(value);
	            var diags = this.Diagnostics;
	            if (diags != null && diags.Count > 0)
	               newNode = newNode.WithDiagnostics(diags);
	            var annotations = this.Annotations;
	            if (annotations != null && annotations.Count > 0)
	               newNode = newNode.WithAnnotations(annotations);
				return (ArgGreen)newNode;
	        }
	        return this;
	    }
	
	    public override TResult Accept<TResult>(CalculatorGreenSyntaxVisitor<TResult> visitor)
	    {
	        return visitor.Visit(this);
	    }
	
	    public override void Accept(CalculatorGreenSyntaxVisitor visitor)
	    {
	        visitor.Visit(this);
	    }
	}

	public class CalculatorGreenSyntaxVisitor : InternalSyntaxVisitor
	{
	    public virtual void Visit(CalculatorGreenNode node)
	    {
	        node.Accept(this);
	    }
	
	    public virtual void Visit(CalculatorGreenSyntaxTrivia node)
	    {
	        node.Accept(this);
	    }
		
		public virtual void VisitMain(MainGreen node)
		{
		    this.DefaultVisit(node);
		}
		
		public virtual void VisitStatementLine(StatementLineGreen node)
		{
		    this.DefaultVisit(node);
		}
		
		public virtual void VisitStatement(StatementGreen node)
		{
		    this.DefaultVisit(node);
		}
		
		public virtual void VisitAssignment(AssignmentGreen node)
		{
		    this.DefaultVisit(node);
		}
		
		public virtual void VisitParenExpression(ParenExpressionGreen node)
		{
		    this.DefaultVisit(node);
		}
		
		public virtual void VisitMulOrDivExpression(MulOrDivExpressionGreen node)
		{
		    this.DefaultVisit(node);
		}
		
		public virtual void VisitAddOrSubExpression(AddOrSubExpressionGreen node)
		{
		    this.DefaultVisit(node);
		}
		
		public virtual void VisitPrintExpression(PrintExpressionGreen node)
		{
		    this.DefaultVisit(node);
		}
		
		public virtual void VisitValueExpression(ValueExpressionGreen node)
		{
		    this.DefaultVisit(node);
		}
		
		public virtual void VisitArgs(ArgsGreen node)
		{
		    this.DefaultVisit(node);
		}
		
		public virtual void VisitValue(ValueGreen node)
		{
		    this.DefaultVisit(node);
		}
		
		public virtual void VisitIdentifier(IdentifierGreen node)
		{
		    this.DefaultVisit(node);
		}
		
		public virtual void VisitString(StringGreen node)
		{
		    this.DefaultVisit(node);
		}
		
		public virtual void VisitInteger(IntegerGreen node)
		{
		    this.DefaultVisit(node);
		}
		
		public virtual void VisitArg(ArgGreen node)
		{
		    this.DefaultVisit(node);
		}
	}

	public class CalculatorGreenSyntaxVisitor<TResult> : InternalSyntaxVisitor<TResult>
	{
	    public virtual TResult Visit(CalculatorGreenNode node)
	    {
	        return node.Accept(this);
	    }
	
	    public virtual TResult Visit(CalculatorGreenSyntaxTrivia node)
	    {
	        return node.Accept(this);
	    }
		
		public virtual TResult VisitMain(MainGreen node)
		{
		    return this.DefaultVisit(node);
		}
		
		public virtual TResult VisitStatementLine(StatementLineGreen node)
		{
		    return this.DefaultVisit(node);
		}
		
		public virtual TResult VisitStatement(StatementGreen node)
		{
		    return this.DefaultVisit(node);
		}
		
		public virtual TResult VisitAssignment(AssignmentGreen node)
		{
		    return this.DefaultVisit(node);
		}
		
		public virtual TResult VisitParenExpression(ParenExpressionGreen node)
		{
		    return this.DefaultVisit(node);
		}
		
		public virtual TResult VisitMulOrDivExpression(MulOrDivExpressionGreen node)
		{
		    return this.DefaultVisit(node);
		}
		
		public virtual TResult VisitAddOrSubExpression(AddOrSubExpressionGreen node)
		{
		    return this.DefaultVisit(node);
		}
		
		public virtual TResult VisitPrintExpression(PrintExpressionGreen node)
		{
		    return this.DefaultVisit(node);
		}
		
		public virtual TResult VisitValueExpression(ValueExpressionGreen node)
		{
		    return this.DefaultVisit(node);
		}
		
		public virtual TResult VisitArgs(ArgsGreen node)
		{
		    return this.DefaultVisit(node);
		}
		
		public virtual TResult VisitValue(ValueGreen node)
		{
		    return this.DefaultVisit(node);
		}
		
		public virtual TResult VisitIdentifier(IdentifierGreen node)
		{
		    return this.DefaultVisit(node);
		}
		
		public virtual TResult VisitString(StringGreen node)
		{
		    return this.DefaultVisit(node);
		}
		
		public virtual TResult VisitInteger(IntegerGreen node)
		{
		    return this.DefaultVisit(node);
		}
		
		public virtual TResult VisitArg(ArgGreen node)
		{
		    return this.DefaultVisit(node);
		}
	}

	public class CalculatorGreenSyntaxRewriter : CalculatorGreenSyntaxVisitor<GreenNode>
	{
	    protected readonly bool VisitIntoStructuredTrivia;
	
	    public CalculatorGreenSyntaxRewriter(bool visitIntoStructuredTrivia = false)
	    {
	        this.VisitIntoStructuredTrivia = visitIntoStructuredTrivia;
	    }
	
	    public override InternalSyntaxToken VisitToken(InternalSyntaxToken token)
	    {
			// TODO
	        throw new NotImplementedException();
	    }
	
	    public InternalSyntaxList<TNode> VisitList<TNode>(InternalSyntaxList<TNode> list) where TNode : GreenNode
	    {
			// TODO
	        throw new NotImplementedException();
	    }
	
	    public InternalSeparatedSyntaxList<TNode> VisitList<TNode>(InternalSeparatedSyntaxList<TNode> list) where TNode : GreenNode
	    {
			// TODO
	        throw new NotImplementedException();
	    }
		
		public override GreenNode VisitMain(MainGreen node)
		{
		    var statementLine = (StatementLineGreen)this.Visit(node.StatementLine);
		    var endOfFileToken = this.VisitToken(node.EndOfFileToken);
			return node.Update(statementLine, endOfFileToken);
		}
		
		public override GreenNode VisitStatementLine(StatementLineGreen node)
		{
		    var statement = (StatementGreen)this.Visit(node.Statement);
		    var tSemicolon = this.VisitToken(node.TSemicolon);
			return node.Update(statement, tSemicolon);
		}
		
		public override GreenNode VisitStatement(StatementGreen node)
		{
		    var assignment = (AssignmentGreen)this.Visit(node.Assignment);
		    var expression = (ExpressionGreen)this.Visit(node.Expression);
			return node.Update(assignment, expression);
		}
		
		public override GreenNode VisitAssignment(AssignmentGreen node)
		{
		    var identifier = (IdentifierGreen)this.Visit(node.Identifier);
		    var tAssign = this.VisitToken(node.TAssign);
		    var expression = (ExpressionGreen)this.Visit(node.Expression);
			return node.Update(identifier, tAssign, expression);
		}
		
		public override GreenNode VisitParenExpression(ParenExpressionGreen node)
		{
		    var tOpenParen = this.VisitToken(node.TOpenParen);
		    var expression = (ExpressionGreen)this.Visit(node.Expression);
		    var tCloseParen = this.VisitToken(node.TCloseParen);
			return node.Update(tOpenParen, expression, tCloseParen);
		}
		
		public override GreenNode VisitMulOrDivExpression(MulOrDivExpressionGreen node)
		{
		    var left = (ExpressionGreen)this.Visit(node.Left);
		    var tMul = this.VisitToken(node.TMul);
		    var tDiv = this.VisitToken(node.TDiv);
		    var right = (ExpressionGreen)this.Visit(node.Right);
			return node.Update(left, tMul, tDiv, right);
		}
		
		public override GreenNode VisitAddOrSubExpression(AddOrSubExpressionGreen node)
		{
		    var left = (ExpressionGreen)this.Visit(node.Left);
		    var tAdd = this.VisitToken(node.TAdd);
		    var tSub = this.VisitToken(node.TSub);
		    var right = (ExpressionGreen)this.Visit(node.Right);
			return node.Update(left, tAdd, tSub, right);
		}
		
		public override GreenNode VisitPrintExpression(PrintExpressionGreen node)
		{
		    var kPrint = this.VisitToken(node.KPrint);
		    var args = (ArgsGreen)this.Visit(node.Args);
			return node.Update(kPrint, args);
		}
		
		public override GreenNode VisitValueExpression(ValueExpressionGreen node)
		{
		    var value = (ValueGreen)this.Visit(node.Value);
			return node.Update(value);
		}
		
		public override GreenNode VisitArgs(ArgsGreen node)
		{
		    var arg = this.VisitList<ArgGreen>(node.Arg);
		    var tComma = this.VisitToken(node.TComma);
			return node.Update(arg, tComma);
		}
		
		public override GreenNode VisitValue(ValueGreen node)
		{
		    var identifier = (IdentifierGreen)this.Visit(node.Identifier);
		    var _string = (StringGreen)this.Visit(node.String);
		    var integer = (IntegerGreen)this.Visit(node.Integer);
			return node.Update(identifier, _string, integer);
		}
		
		public override GreenNode VisitIdentifier(IdentifierGreen node)
		{
		    var iD = this.VisitToken(node.ID);
			return node.Update(iD);
		}
		
		public override GreenNode VisitString(StringGreen node)
		{
		    var sTRING = this.VisitToken(node.STRING);
			return node.Update(sTRING);
		}
		
		public override GreenNode VisitInteger(IntegerGreen node)
		{
		    var iNT = this.VisitToken(node.INT);
			return node.Update(iNT);
		}
		
		public override GreenNode VisitArg(ArgGreen node)
		{
		    var value = (ValueGreen)this.Visit(node.Value);
			return node.Update(value);
		}
	}

	public class CalculatorGreenFactory : InternalSyntaxFactory
	{
	    public static InternalSyntaxToken Token(CalculatorSyntaxKind kind)
	    {
			string text = CalculatorSyntaxFacts.GetText(kind);
	        return InternalSyntaxToken.Create((int)kind, text.Length);
	    }
	
	    internal static InternalSyntaxToken Token(GreenNode leading, CalculatorSyntaxKind kind, GreenNode trailing)
	    {
			string text = CalculatorSyntaxFacts.GetText(kind);
	        return InternalSyntaxToken.Create((int)kind, text.Length, leading, trailing);
	    }
	
	    internal static InternalSyntaxToken STRING(string text)
	    {
	        return InternalSyntaxToken.CreateWithText((int)CalculatorSyntaxKind.STRING, text);
	    }
	
	    internal static InternalSyntaxToken STRING(string text, object value)
	    {
	        return InternalSyntaxToken.CreateWithValue((int)CalculatorSyntaxKind.STRING, text, value);
	    }
	
	    internal static InternalSyntaxToken ID(string text)
	    {
	        return InternalSyntaxToken.CreateWithText((int)CalculatorSyntaxKind.ID, text);
	    }
	
	    internal static InternalSyntaxToken ID(string text, object value)
	    {
	        return InternalSyntaxToken.CreateWithValue((int)CalculatorSyntaxKind.ID, text, value);
	    }
	
	    internal static InternalSyntaxToken INT(string text)
	    {
	        return InternalSyntaxToken.CreateWithText((int)CalculatorSyntaxKind.INT, text);
	    }
	
	    internal static InternalSyntaxToken INT(string text, object value)
	    {
	        return InternalSyntaxToken.CreateWithValue((int)CalculatorSyntaxKind.INT, text, value);
	    }
	
	    internal static InternalSyntaxToken UTF8BOM(string text)
	    {
	        return InternalSyntaxToken.CreateWithText((int)CalculatorSyntaxKind.UTF8BOM, text);
	    }
	
	    internal static InternalSyntaxToken UTF8BOM(string text, object value)
	    {
	        return InternalSyntaxToken.CreateWithValue((int)CalculatorSyntaxKind.UTF8BOM, text, value);
	    }
	
	    internal static InternalSyntaxToken WHITESPACE(string text)
	    {
	        return InternalSyntaxToken.CreateWithText((int)CalculatorSyntaxKind.WHITESPACE, text);
	    }
	
	    internal static InternalSyntaxToken WHITESPACE(string text, object value)
	    {
	        return InternalSyntaxToken.CreateWithValue((int)CalculatorSyntaxKind.WHITESPACE, text, value);
	    }
	
	    internal static InternalSyntaxToken ENDL(string text)
	    {
	        return InternalSyntaxToken.CreateWithText((int)CalculatorSyntaxKind.ENDL, text);
	    }
	
	    internal static InternalSyntaxToken ENDL(string text, object value)
	    {
	        return InternalSyntaxToken.CreateWithValue((int)CalculatorSyntaxKind.ENDL, text, value);
	    }
	
	    internal static InternalSyntaxToken COMMENT(string text)
	    {
	        return InternalSyntaxToken.CreateWithText((int)CalculatorSyntaxKind.COMMENT, text);
	    }
	
	    internal static InternalSyntaxToken COMMENT(string text, object value)
	    {
	        return InternalSyntaxToken.CreateWithValue((int)CalculatorSyntaxKind.COMMENT, text, value);
	    }
	
		public static MainGreen Main(StatementLineGreen statementLine, InternalSyntaxToken endOfFileToken)
	    {
	#if DEBUG
	        if (statementLine == null) throw new ArgumentNullException(nameof(statementLine));
	        if (endOfFileToken == null) throw new ArgumentNullException(nameof(endOfFileToken));
	        if (endOfFileToken.RawKind != (int)CalculatorSyntaxKind.EOF) throw new ArgumentException(nameof(endOfFileToken));
	#endif
	        return new MainGreen(CalculatorSyntaxKind.Main, statementLine, endOfFileToken);
	    }
	
		public static StatementLineGreen StatementLine(StatementGreen statement, InternalSyntaxToken tSemicolon)
	    {
	#if DEBUG
	        if (statement == null) throw new ArgumentNullException(nameof(statement));
	        if (tSemicolon == null) throw new ArgumentNullException(nameof(tSemicolon));
	        if (tSemicolon.RawKind != (int)CalculatorSyntaxKind.TSemicolon) throw new ArgumentException(nameof(tSemicolon));
	#endif
	        return new StatementLineGreen(CalculatorSyntaxKind.StatementLine, statement, tSemicolon);
	    }
	
		public static StatementGreen Statement(AssignmentGreen assignment, ExpressionGreen expression)
	    {
	#if DEBUG
	#endif
	        return new StatementGreen(CalculatorSyntaxKind.Statement, assignment, expression);
	    }
	
		public static AssignmentGreen Assignment(IdentifierGreen identifier, InternalSyntaxToken tAssign, ExpressionGreen expression)
	    {
	#if DEBUG
	        if (identifier == null) throw new ArgumentNullException(nameof(identifier));
	        if (tAssign == null) throw new ArgumentNullException(nameof(tAssign));
	        if (tAssign.RawKind != (int)CalculatorSyntaxKind.TAssign) throw new ArgumentException(nameof(tAssign));
	        if (expression == null) throw new ArgumentNullException(nameof(expression));
	#endif
	        return new AssignmentGreen(CalculatorSyntaxKind.Assignment, identifier, tAssign, expression);
	    }
	
		public static ParenExpressionGreen ParenExpression(InternalSyntaxToken tOpenParen, ExpressionGreen expression, InternalSyntaxToken tCloseParen)
	    {
	#if DEBUG
	        if (tOpenParen == null) throw new ArgumentNullException(nameof(tOpenParen));
	        if (tOpenParen.RawKind != (int)CalculatorSyntaxKind.TOpenParen) throw new ArgumentException(nameof(tOpenParen));
	        if (expression == null) throw new ArgumentNullException(nameof(expression));
	        if (tCloseParen == null) throw new ArgumentNullException(nameof(tCloseParen));
	        if (tCloseParen.RawKind != (int)CalculatorSyntaxKind.TCloseParen) throw new ArgumentException(nameof(tCloseParen));
	#endif
	        return new ParenExpressionGreen(CalculatorSyntaxKind.ParenExpression, tOpenParen, expression, tCloseParen);
	    }
	
		public static MulOrDivExpressionGreen MulOrDivExpression(ExpressionGreen left, InternalSyntaxToken tMul, InternalSyntaxToken tDiv, ExpressionGreen right)
	    {
	#if DEBUG
	        if (left == null) throw new ArgumentNullException(nameof(left));
	        if (tMul != null && tMul.RawKind != (int)CalculatorSyntaxKind.TMul) throw new ArgumentException(nameof(tMul));
	        if (tDiv != null && tDiv.RawKind != (int)CalculatorSyntaxKind.TDiv) throw new ArgumentException(nameof(tDiv));
	        if (right == null) throw new ArgumentNullException(nameof(right));
	#endif
	        return new MulOrDivExpressionGreen(CalculatorSyntaxKind.MulOrDivExpression, left, tMul, tDiv, right);
	    }
	
		public static AddOrSubExpressionGreen AddOrSubExpression(ExpressionGreen left, InternalSyntaxToken tAdd, InternalSyntaxToken tSub, ExpressionGreen right)
	    {
	#if DEBUG
	        if (left == null) throw new ArgumentNullException(nameof(left));
	        if (tAdd != null && tAdd.RawKind != (int)CalculatorSyntaxKind.TAdd) throw new ArgumentException(nameof(tAdd));
	        if (tSub != null && tSub.RawKind != (int)CalculatorSyntaxKind.TSub) throw new ArgumentException(nameof(tSub));
	        if (right == null) throw new ArgumentNullException(nameof(right));
	#endif
	        return new AddOrSubExpressionGreen(CalculatorSyntaxKind.AddOrSubExpression, left, tAdd, tSub, right);
	    }
	
		public static PrintExpressionGreen PrintExpression(InternalSyntaxToken kPrint, ArgsGreen args)
	    {
	#if DEBUG
	        if (kPrint == null) throw new ArgumentNullException(nameof(kPrint));
	        if (kPrint.RawKind != (int)CalculatorSyntaxKind.KPrint) throw new ArgumentException(nameof(kPrint));
	        if (args == null) throw new ArgumentNullException(nameof(args));
	#endif
	        return new PrintExpressionGreen(CalculatorSyntaxKind.PrintExpression, kPrint, args);
	    }
	
		public static ValueExpressionGreen ValueExpression(ValueGreen value)
	    {
	#if DEBUG
	        if (value == null) throw new ArgumentNullException(nameof(value));
	#endif
	        return new ValueExpressionGreen(CalculatorSyntaxKind.ValueExpression, value);
	    }
	
		public static ArgsGreen Args(InternalSyntaxList<ArgGreen> arg, InternalSyntaxToken tComma)
	    {
	#if DEBUG
	        if (arg == null) throw new ArgumentNullException(nameof(arg));
	        if (tComma == null) throw new ArgumentNullException(nameof(tComma));
	        if (tComma.RawKind != (int)CalculatorSyntaxKind.TComma) throw new ArgumentException(nameof(tComma));
	#endif
	        return new ArgsGreen(CalculatorSyntaxKind.Args, arg, tComma);
	    }
	
		public static ValueGreen Value(IdentifierGreen identifier, StringGreen _string, IntegerGreen integer)
	    {
	#if DEBUG
	#endif
	        return new ValueGreen(CalculatorSyntaxKind.Value, identifier, _string, integer);
	    }
	
		public static IdentifierGreen Identifier(InternalSyntaxToken iD)
	    {
	#if DEBUG
	        if (iD == null) throw new ArgumentNullException(nameof(iD));
	        if (iD.RawKind != (int)CalculatorSyntaxKind.ID) throw new ArgumentException(nameof(iD));
	#endif
	        return new IdentifierGreen(CalculatorSyntaxKind.Identifier, iD);
	    }
	
		public static StringGreen String(InternalSyntaxToken sTRING)
	    {
	#if DEBUG
	        if (sTRING == null) throw new ArgumentNullException(nameof(sTRING));
	        if (sTRING.RawKind != (int)CalculatorSyntaxKind.STRING) throw new ArgumentException(nameof(sTRING));
	#endif
	        return new StringGreen(CalculatorSyntaxKind.String, sTRING);
	    }
	
		public static IntegerGreen Integer(InternalSyntaxToken iNT)
	    {
	#if DEBUG
	        if (iNT == null) throw new ArgumentNullException(nameof(iNT));
	        if (iNT.RawKind != (int)CalculatorSyntaxKind.INT) throw new ArgumentException(nameof(iNT));
	#endif
	        return new IntegerGreen(CalculatorSyntaxKind.Integer, iNT);
	    }
	
		public static ArgGreen Arg(ValueGreen value)
	    {
	#if DEBUG
	        if (value == null) throw new ArgumentNullException(nameof(value));
	#endif
	        return new ArgGreen(CalculatorSyntaxKind.Arg, value);
	    }
	
	    internal static IEnumerable<Type> GetNodeTypes()
	    {
	        return new Type[] {
				typeof(MainGreen),
				typeof(StatementLineGreen),
				typeof(StatementGreen),
				typeof(AssignmentGreen),
				typeof(ParenExpressionGreen),
				typeof(MulOrDivExpressionGreen),
				typeof(AddOrSubExpressionGreen),
				typeof(PrintExpressionGreen),
				typeof(ValueExpressionGreen),
				typeof(ArgsGreen),
				typeof(ValueGreen),
				typeof(IdentifierGreen),
				typeof(StringGreen),
				typeof(IntegerGreen),
				typeof(ArgGreen),
			};
		}
	}
}

