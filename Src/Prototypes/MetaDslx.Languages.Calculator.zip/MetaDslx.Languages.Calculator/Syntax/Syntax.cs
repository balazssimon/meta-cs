using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MetaDslx.Compiler.Core.Diagnostics;
using MetaDslx.Compiler.Core.Syntax;

namespace MetaDslx.Languages.Calculator.Syntax
{
	public enum CalculatorSyntaxKind : int
	{
		None = 0,
		EOF = MetaDslx.Compiler.Core.Syntax.SyntaxKind.EOF,
		List = MetaDslx.Compiler.Core.Syntax.SyntaxKind.List,
		SkippedTokens = MetaDslx.Compiler.Core.Syntax.SyntaxKind.SkippedTokens,

		// Tokens:
		TSemicolon,
		TOpenParen,
		TCloseParen,
		TComma,
		TAssign,
		TAdd,
		TSub,
		TMul,
		TDiv,
		KPrint,
		STRING,
		ID,
		INT,
		UTF8BOM,
		WHITESPACE,
		ENDL,
		COMMENT,

		// Rules:
		Main,
		StatementLine,
		Statement,
		Assignment,
		ParenExpression,
		MulOrDivExpression,
		AddOrSubExpression,
		PrintExpression,
		ValueExpression,
		Args,
		Value,
		Identifier,
		String,
		Integer,
		Arg,
	}
    public abstract class CalculatorSyntaxNode : SyntaxNode
    {
        protected CalculatorSyntaxNode(GreenNode green, SyntaxNode parent, int position)
            : base(green, parent, parent?.SyntaxTree, position, -1)
        {
        }
        public CalculatorSyntaxKind Kind
        {
            get { return (CalculatorSyntaxKind)base.RawKind; }
        }
        /// <summary>
        /// <para>
        /// Internal helper for <see cref="CalculatorSyntaxNode"/> class to create a new syntax tree rooted at the given root node.
        /// This method does not create a clone of the given root, but instead preserves it's reference identity.
        /// </para>
        /// <para>NOTE: This method is only intended to be used from <see cref="SyntaxNode.SyntaxTree"/> property.</para>
        /// <para>NOTE: Do not use this method elsewhere!</para>
        /// </summary>
        protected override SyntaxTree CreateTreeWithoutClone()
        {
			return CalculatorSyntaxTree.CreateWithoutClone(this);
        }
        public override TResult Accept<TResult>(SyntaxVisitor<TResult> visitor)
        {
            CalculatorSyntaxVisitor<TResult> typedVisitor = visitor as CalculatorSyntaxVisitor<TResult>;
            if (typedVisitor != null)
            {
                return this.Accept(visitor);
            }
            return default(TResult);
        }
        public abstract TResult Accept<TResult>(CalculatorSyntaxVisitor<TResult> visitor);
        public override void Accept(SyntaxVisitor visitor)
        {
            CalculatorSyntaxVisitor typedVisitor = visitor as CalculatorSyntaxVisitor;
            if (typedVisitor != null)
            {
                this.Accept(visitor);
            }
        }
        public abstract void Accept(CalculatorSyntaxVisitor visitor);
    }

    public abstract class CalculatorSyntaxTrivia : SyntaxTrivia
    {
        protected CalculatorSyntaxTrivia(GreenNode green, SyntaxNode parent, int position)
            : base(green, parent, position)
        {
        }
        public CalculatorSyntaxKind Kind
        {
            get { return (CalculatorSyntaxKind)base.RawKind; }
        }
        public override TResult Accept<TResult>(SyntaxVisitor<TResult> visitor)
        {
            CalculatorSyntaxVisitor<TResult> typedVisitor = visitor as CalculatorSyntaxVisitor<TResult>;
            if (typedVisitor != null)
            {
                return this.Accept(visitor);
            }
            return default(TResult);
        }
        public abstract TResult Accept<TResult>(CalculatorSyntaxVisitor<TResult> visitor);
        public override void Accept(SyntaxVisitor visitor)
        {
            CalculatorSyntaxVisitor typedVisitor = visitor as CalculatorSyntaxVisitor;
            if (typedVisitor != null)
            {
                this.Accept(visitor);
            }
        }
        public abstract void Accept(CalculatorSyntaxVisitor visitor);
    }
	
	public class MainSyntax : CalculatorSyntaxNode, ICompilationUnitSyntax
	{
	    private StatementLineSyntax statementLine;
	
	    public MainSyntax(GreenNode green, SyntaxNode parent, int position)
	        : base(green, parent, position)
	    {
	    }
	
	    public StatementLineSyntax StatementLine 
		{ 
			get
			{
				return this.GetRed(ref this.statementLine, 0);
			} 
		}
	    public SyntaxToken EndOfFileToken { get { return new SyntaxToken(((global::MetaDslx.Languages.Calculator.Syntax.InternalSyntax.MainGreen)this.Green).EndOfFileToken, this, this.GetChildPosition(1), this.GetChildIndex(1)); } }
	
	    public override SyntaxNode GetSlot(int index)
	    {
	        switch (index)
	        {
				case 0: return this.GetRed(ref this.statementLine, 0);
				default: return null;
	        }
	    }
	
	    public override SyntaxNode GetCachedSlot(int index)
	    {
	        switch (index)
	        {
				case 0: return this.statementLine;
				default: return null;
	        }
	    }
	
	    public override SyntaxNode WithAnnotations(ImmutableList<SyntaxAnnotation> annotations)
	    {
	        return this.Green.WithAnnotations(annotations).CreateRed();
	    }
	
	    public MainSyntax WithStatementLine(StatementLineSyntax statementLine)
		{
			return this.Update(StatementLine, this.EndOfFileToken);
		}
	
	    public MainSyntax WithEndOfFileToken(SyntaxToken endOfFileToken)
		{
			return this.Update(this.StatementLine, EndOfFileToken);
		}
	
	    public MainSyntax Update(StatementLineSyntax statementLine, SyntaxToken endOfFileToken)
	    {
	        if (this.StatementLine != statementLine ||
				this.EndOfFileToken != endOfFileToken)
	        {
	            SyntaxNode newNode = CalculatorSyntaxFactory.Main(statementLine, endOfFileToken);
	            var annotations = this.Annotations;
	            if (annotations != null && annotations.Count > 0)
	               newNode = newNode.WithAnnotations(annotations);
				return (MainSyntax)newNode;
	        }
	        return this;
	    }
	
	    public override TResult Accept<TResult>(CalculatorSyntaxVisitor<TResult> visitor)
	    {
	        return visitor.Visit(this);
	    }
	
	    public override void Accept(CalculatorSyntaxVisitor visitor)
	    {
	        visitor.Visit(this);
	    }
	}
	
	public class StatementLineSyntax : CalculatorSyntaxNode
	{
	    private StatementSyntax statement;
	
	    public StatementLineSyntax(GreenNode green, SyntaxNode parent, int position)
	        : base(green, parent, position)
	    {
	    }
	
	    public StatementSyntax Statement 
		{ 
			get
			{
				return this.GetRed(ref this.statement, 0);
			} 
		}
	    public SyntaxToken TSemicolon { get { return new SyntaxToken(((global::MetaDslx.Languages.Calculator.Syntax.InternalSyntax.StatementLineGreen)this.Green).TSemicolon, this, this.GetChildPosition(1), this.GetChildIndex(1)); } }
	
	    public override SyntaxNode GetSlot(int index)
	    {
	        switch (index)
	        {
				case 0: return this.GetRed(ref this.statement, 0);
				default: return null;
	        }
	    }
	
	    public override SyntaxNode GetCachedSlot(int index)
	    {
	        switch (index)
	        {
				case 0: return this.statement;
				default: return null;
	        }
	    }
	
	    public override SyntaxNode WithAnnotations(ImmutableList<SyntaxAnnotation> annotations)
	    {
	        return this.Green.WithAnnotations(annotations).CreateRed();
	    }
	
	    public StatementLineSyntax WithStatement(StatementSyntax statement)
		{
			return this.Update(Statement, this.TSemicolon);
		}
	
	    public StatementLineSyntax WithTSemicolon(SyntaxToken tSemicolon)
		{
			return this.Update(this.Statement, TSemicolon);
		}
	
	    public StatementLineSyntax Update(StatementSyntax statement, SyntaxToken tSemicolon)
	    {
	        if (this.Statement != statement ||
				this.TSemicolon != tSemicolon)
	        {
	            SyntaxNode newNode = CalculatorSyntaxFactory.StatementLine(statement, tSemicolon);
	            var annotations = this.Annotations;
	            if (annotations != null && annotations.Count > 0)
	               newNode = newNode.WithAnnotations(annotations);
				return (StatementLineSyntax)newNode;
	        }
	        return this;
	    }
	
	    public override TResult Accept<TResult>(CalculatorSyntaxVisitor<TResult> visitor)
	    {
	        return visitor.Visit(this);
	    }
	
	    public override void Accept(CalculatorSyntaxVisitor visitor)
	    {
	        visitor.Visit(this);
	    }
	}
	
	public class StatementSyntax : CalculatorSyntaxNode
	{
	    private AssignmentSyntax assignment;
	    private ExpressionSyntax expression;
	
	    public StatementSyntax(GreenNode green, SyntaxNode parent, int position)
	        : base(green, parent, position)
	    {
	    }
	
	    public AssignmentSyntax Assignment 
		{ 
			get
			{
				return this.GetRed(ref this.assignment, 0);
			} 
		}
	    public ExpressionSyntax Expression 
		{ 
			get
			{
				return this.GetRed(ref this.expression, 1);
			} 
		}
	
	    public override SyntaxNode GetSlot(int index)
	    {
	        switch (index)
	        {
				case 0: return this.GetRed(ref this.assignment, 0);
				case 1: return this.GetRed(ref this.expression, 1);
				default: return null;
	        }
	    }
	
	    public override SyntaxNode GetCachedSlot(int index)
	    {
	        switch (index)
	        {
				case 0: return this.assignment;
				case 1: return this.expression;
				default: return null;
	        }
	    }
	
	    public override SyntaxNode WithAnnotations(ImmutableList<SyntaxAnnotation> annotations)
	    {
	        return this.Green.WithAnnotations(annotations).CreateRed();
	    }
	
	    public StatementSyntax WithAssignment(AssignmentSyntax assignment)
		{
			return this.Update(Assignment, this.Expression);
		}
	
	    public StatementSyntax WithExpression(ExpressionSyntax expression)
		{
			return this.Update(this.Assignment, Expression);
		}
	
	    public StatementSyntax Update(AssignmentSyntax assignment, ExpressionSyntax expression)
	    {
	        if (this.Assignment != assignment ||
				this.Expression != expression)
	        {
	            SyntaxNode newNode = CalculatorSyntaxFactory.Statement(assignment, expression);
	            var annotations = this.Annotations;
	            if (annotations != null && annotations.Count > 0)
	               newNode = newNode.WithAnnotations(annotations);
				return (StatementSyntax)newNode;
	        }
	        return this;
	    }
	
	    public override TResult Accept<TResult>(CalculatorSyntaxVisitor<TResult> visitor)
	    {
	        return visitor.Visit(this);
	    }
	
	    public override void Accept(CalculatorSyntaxVisitor visitor)
	    {
	        visitor.Visit(this);
	    }
	}
	
	public class AssignmentSyntax : CalculatorSyntaxNode
	{
	    private IdentifierSyntax identifier;
	    private ExpressionSyntax expression;
	
	    public AssignmentSyntax(GreenNode green, SyntaxNode parent, int position)
	        : base(green, parent, position)
	    {
	    }
	
	    public IdentifierSyntax Identifier 
		{ 
			get
			{
				return this.GetRed(ref this.identifier, 0);
			} 
		}
	    public SyntaxToken TAssign { get { return new SyntaxToken(((global::MetaDslx.Languages.Calculator.Syntax.InternalSyntax.AssignmentGreen)this.Green).TAssign, this, this.GetChildPosition(1), this.GetChildIndex(1)); } }
	    public ExpressionSyntax Expression 
		{ 
			get
			{
				return this.GetRed(ref this.expression, 2);
			} 
		}
	
	    public override SyntaxNode GetSlot(int index)
	    {
	        switch (index)
	        {
				case 0: return this.GetRed(ref this.identifier, 0);
				case 2: return this.GetRed(ref this.expression, 2);
				default: return null;
	        }
	    }
	
	    public override SyntaxNode GetCachedSlot(int index)
	    {
	        switch (index)
	        {
				case 0: return this.identifier;
				case 2: return this.expression;
				default: return null;
	        }
	    }
	
	    public override SyntaxNode WithAnnotations(ImmutableList<SyntaxAnnotation> annotations)
	    {
	        return this.Green.WithAnnotations(annotations).CreateRed();
	    }
	
	    public AssignmentSyntax WithIdentifier(IdentifierSyntax identifier)
		{
			return this.Update(Identifier, this.TAssign, this.Expression);
		}
	
	    public AssignmentSyntax WithTAssign(SyntaxToken tAssign)
		{
			return this.Update(this.Identifier, TAssign, this.Expression);
		}
	
	    public AssignmentSyntax WithExpression(ExpressionSyntax expression)
		{
			return this.Update(this.Identifier, this.TAssign, Expression);
		}
	
	    public AssignmentSyntax Update(IdentifierSyntax identifier, SyntaxToken tAssign, ExpressionSyntax expression)
	    {
	        if (this.Identifier != identifier ||
				this.TAssign != tAssign ||
				this.Expression != expression)
	        {
	            SyntaxNode newNode = CalculatorSyntaxFactory.Assignment(identifier, tAssign, expression);
	            var annotations = this.Annotations;
	            if (annotations != null && annotations.Count > 0)
	               newNode = newNode.WithAnnotations(annotations);
				return (AssignmentSyntax)newNode;
	        }
	        return this;
	    }
	
	    public override TResult Accept<TResult>(CalculatorSyntaxVisitor<TResult> visitor)
	    {
	        return visitor.Visit(this);
	    }
	
	    public override void Accept(CalculatorSyntaxVisitor visitor)
	    {
	        visitor.Visit(this);
	    }
	}
	
	public abstract class ExpressionSyntax : CalculatorSyntaxNode
	{
	
	    public ExpressionSyntax(GreenNode green, SyntaxNode parent, int position)
	        : base(green, parent, position)
	    {
	    }
	}
	
	public class ParenExpressionSyntax : ExpressionSyntax
	{
	    private ExpressionSyntax expression;
	
	    public ParenExpressionSyntax(GreenNode green, SyntaxNode parent, int position)
	        : base(green, parent, position)
	    {
	    }
	
	    public SyntaxToken TOpenParen { get { return new SyntaxToken(((global::MetaDslx.Languages.Calculator.Syntax.InternalSyntax.ParenExpressionGreen)this.Green).TOpenParen, this, this.GetChildPosition(0), this.GetChildIndex(0)); } }
	    public ExpressionSyntax Expression 
		{ 
			get
			{
				return this.GetRed(ref this.expression, 1);
			} 
		}
	    public SyntaxToken TCloseParen { get { return new SyntaxToken(((global::MetaDslx.Languages.Calculator.Syntax.InternalSyntax.ParenExpressionGreen)this.Green).TCloseParen, this, this.GetChildPosition(2), this.GetChildIndex(2)); } }
	
	    public override SyntaxNode GetSlot(int index)
	    {
	        switch (index)
	        {
				case 1: return this.GetRed(ref this.expression, 1);
				default: return null;
	        }
	    }
	
	    public override SyntaxNode GetCachedSlot(int index)
	    {
	        switch (index)
	        {
				case 1: return this.expression;
				default: return null;
	        }
	    }
	
	    public override SyntaxNode WithAnnotations(ImmutableList<SyntaxAnnotation> annotations)
	    {
	        return this.Green.WithAnnotations(annotations).CreateRed();
	    }
	
	    public ParenExpressionSyntax WithTOpenParen(SyntaxToken tOpenParen)
		{
			return this.Update(TOpenParen, this.Expression, this.TCloseParen);
		}
	
	    public ParenExpressionSyntax WithExpression(ExpressionSyntax expression)
		{
			return this.Update(this.TOpenParen, Expression, this.TCloseParen);
		}
	
	    public ParenExpressionSyntax WithTCloseParen(SyntaxToken tCloseParen)
		{
			return this.Update(this.TOpenParen, this.Expression, TCloseParen);
		}
	
	    public ParenExpressionSyntax Update(SyntaxToken tOpenParen, ExpressionSyntax expression, SyntaxToken tCloseParen)
	    {
	        if (this.TOpenParen != tOpenParen ||
				this.Expression != expression ||
				this.TCloseParen != tCloseParen)
	        {
	            SyntaxNode newNode = CalculatorSyntaxFactory.ParenExpression(tOpenParen, expression, tCloseParen);
	            var annotations = this.Annotations;
	            if (annotations != null && annotations.Count > 0)
	               newNode = newNode.WithAnnotations(annotations);
				return (ParenExpressionSyntax)newNode;
	        }
	        return this;
	    }
	
	    public override TResult Accept<TResult>(CalculatorSyntaxVisitor<TResult> visitor)
	    {
	        return visitor.Visit(this);
	    }
	
	    public override void Accept(CalculatorSyntaxVisitor visitor)
	    {
	        visitor.Visit(this);
	    }
	}
	
	public class MulOrDivExpressionSyntax : ExpressionSyntax
	{
	    private ExpressionSyntax left;
	    private ExpressionSyntax right;
	
	    public MulOrDivExpressionSyntax(GreenNode green, SyntaxNode parent, int position)
	        : base(green, parent, position)
	    {
	    }
	
	    public ExpressionSyntax Left 
		{ 
			get
			{
				return this.GetRed(ref this.left, 0);
			} 
		}
	    public SyntaxToken TMul { get { return new SyntaxToken(((global::MetaDslx.Languages.Calculator.Syntax.InternalSyntax.MulOrDivExpressionGreen)this.Green).TMul, this, this.GetChildPosition(1), this.GetChildIndex(1)); } }
	    public SyntaxToken TDiv { get { return new SyntaxToken(((global::MetaDslx.Languages.Calculator.Syntax.InternalSyntax.MulOrDivExpressionGreen)this.Green).TDiv, this, this.GetChildPosition(2), this.GetChildIndex(2)); } }
	    public ExpressionSyntax Right 
		{ 
			get
			{
				return this.GetRed(ref this.right, 3);
			} 
		}
	
	    public override SyntaxNode GetSlot(int index)
	    {
	        switch (index)
	        {
				case 0: return this.GetRed(ref this.left, 0);
				case 3: return this.GetRed(ref this.right, 3);
				default: return null;
	        }
	    }
	
	    public override SyntaxNode GetCachedSlot(int index)
	    {
	        switch (index)
	        {
				case 0: return this.left;
				case 3: return this.right;
				default: return null;
	        }
	    }
	
	    public override SyntaxNode WithAnnotations(ImmutableList<SyntaxAnnotation> annotations)
	    {
	        return this.Green.WithAnnotations(annotations).CreateRed();
	    }
	
	    public MulOrDivExpressionSyntax WithLeft(ExpressionSyntax left)
		{
			return this.Update(Left, this.TMul, this.TDiv, this.Right);
		}
	
	    public MulOrDivExpressionSyntax WithTMul(SyntaxToken tMul)
		{
			return this.Update(this.Left, TMul, this.TDiv, this.Right);
		}
	
	    public MulOrDivExpressionSyntax WithTDiv(SyntaxToken tDiv)
		{
			return this.Update(this.Left, this.TMul, TDiv, this.Right);
		}
	
	    public MulOrDivExpressionSyntax WithRight(ExpressionSyntax right)
		{
			return this.Update(this.Left, this.TMul, this.TDiv, Right);
		}
	
	    public MulOrDivExpressionSyntax Update(ExpressionSyntax left, SyntaxToken tMul, SyntaxToken tDiv, ExpressionSyntax right)
	    {
	        if (this.Left != left ||
				this.TMul != tMul ||
				this.TDiv != tDiv ||
				this.Right != right)
	        {
	            SyntaxNode newNode = CalculatorSyntaxFactory.MulOrDivExpression(left, tMul, tDiv, right);
	            var annotations = this.Annotations;
	            if (annotations != null && annotations.Count > 0)
	               newNode = newNode.WithAnnotations(annotations);
				return (MulOrDivExpressionSyntax)newNode;
	        }
	        return this;
	    }
	
	    public override TResult Accept<TResult>(CalculatorSyntaxVisitor<TResult> visitor)
	    {
	        return visitor.Visit(this);
	    }
	
	    public override void Accept(CalculatorSyntaxVisitor visitor)
	    {
	        visitor.Visit(this);
	    }
	}
	
	public class AddOrSubExpressionSyntax : ExpressionSyntax
	{
	    private ExpressionSyntax left;
	    private ExpressionSyntax right;
	
	    public AddOrSubExpressionSyntax(GreenNode green, SyntaxNode parent, int position)
	        : base(green, parent, position)
	    {
	    }
	
	    public ExpressionSyntax Left 
		{ 
			get
			{
				return this.GetRed(ref this.left, 0);
			} 
		}
	    public SyntaxToken TAdd { get { return new SyntaxToken(((global::MetaDslx.Languages.Calculator.Syntax.InternalSyntax.AddOrSubExpressionGreen)this.Green).TAdd, this, this.GetChildPosition(1), this.GetChildIndex(1)); } }
	    public SyntaxToken TSub { get { return new SyntaxToken(((global::MetaDslx.Languages.Calculator.Syntax.InternalSyntax.AddOrSubExpressionGreen)this.Green).TSub, this, this.GetChildPosition(2), this.GetChildIndex(2)); } }
	    public ExpressionSyntax Right 
		{ 
			get
			{
				return this.GetRed(ref this.right, 3);
			} 
		}
	
	    public override SyntaxNode GetSlot(int index)
	    {
	        switch (index)
	        {
				case 0: return this.GetRed(ref this.left, 0);
				case 3: return this.GetRed(ref this.right, 3);
				default: return null;
	        }
	    }
	
	    public override SyntaxNode GetCachedSlot(int index)
	    {
	        switch (index)
	        {
				case 0: return this.left;
				case 3: return this.right;
				default: return null;
	        }
	    }
	
	    public override SyntaxNode WithAnnotations(ImmutableList<SyntaxAnnotation> annotations)
	    {
	        return this.Green.WithAnnotations(annotations).CreateRed();
	    }
	
	    public AddOrSubExpressionSyntax WithLeft(ExpressionSyntax left)
		{
			return this.Update(Left, this.TAdd, this.TSub, this.Right);
		}
	
	    public AddOrSubExpressionSyntax WithTAdd(SyntaxToken tAdd)
		{
			return this.Update(this.Left, TAdd, this.TSub, this.Right);
		}
	
	    public AddOrSubExpressionSyntax WithTSub(SyntaxToken tSub)
		{
			return this.Update(this.Left, this.TAdd, TSub, this.Right);
		}
	
	    public AddOrSubExpressionSyntax WithRight(ExpressionSyntax right)
		{
			return this.Update(this.Left, this.TAdd, this.TSub, Right);
		}
	
	    public AddOrSubExpressionSyntax Update(ExpressionSyntax left, SyntaxToken tAdd, SyntaxToken tSub, ExpressionSyntax right)
	    {
	        if (this.Left != left ||
				this.TAdd != tAdd ||
				this.TSub != tSub ||
				this.Right != right)
	        {
	            SyntaxNode newNode = CalculatorSyntaxFactory.AddOrSubExpression(left, tAdd, tSub, right);
	            var annotations = this.Annotations;
	            if (annotations != null && annotations.Count > 0)
	               newNode = newNode.WithAnnotations(annotations);
				return (AddOrSubExpressionSyntax)newNode;
	        }
	        return this;
	    }
	
	    public override TResult Accept<TResult>(CalculatorSyntaxVisitor<TResult> visitor)
	    {
	        return visitor.Visit(this);
	    }
	
	    public override void Accept(CalculatorSyntaxVisitor visitor)
	    {
	        visitor.Visit(this);
	    }
	}
	
	public class PrintExpressionSyntax : ExpressionSyntax
	{
	    private ArgsSyntax args;
	
	    public PrintExpressionSyntax(GreenNode green, SyntaxNode parent, int position)
	        : base(green, parent, position)
	    {
	    }
	
	    public SyntaxToken KPrint { get { return new SyntaxToken(((global::MetaDslx.Languages.Calculator.Syntax.InternalSyntax.PrintExpressionGreen)this.Green).KPrint, this, this.GetChildPosition(0), this.GetChildIndex(0)); } }
	    public ArgsSyntax Args 
		{ 
			get
			{
				return this.GetRed(ref this.args, 1);
			} 
		}
	
	    public override SyntaxNode GetSlot(int index)
	    {
	        switch (index)
	        {
				case 1: return this.GetRed(ref this.args, 1);
				default: return null;
	        }
	    }
	
	    public override SyntaxNode GetCachedSlot(int index)
	    {
	        switch (index)
	        {
				case 1: return this.args;
				default: return null;
	        }
	    }
	
	    public override SyntaxNode WithAnnotations(ImmutableList<SyntaxAnnotation> annotations)
	    {
	        return this.Green.WithAnnotations(annotations).CreateRed();
	    }
	
	    public PrintExpressionSyntax WithKPrint(SyntaxToken kPrint)
		{
			return this.Update(KPrint, this.Args);
		}
	
	    public PrintExpressionSyntax WithArgs(ArgsSyntax args)
		{
			return this.Update(this.KPrint, Args);
		}
	
	    public PrintExpressionSyntax Update(SyntaxToken kPrint, ArgsSyntax args)
	    {
	        if (this.KPrint != kPrint ||
				this.Args != args)
	        {
	            SyntaxNode newNode = CalculatorSyntaxFactory.PrintExpression(kPrint, args);
	            var annotations = this.Annotations;
	            if (annotations != null && annotations.Count > 0)
	               newNode = newNode.WithAnnotations(annotations);
				return (PrintExpressionSyntax)newNode;
	        }
	        return this;
	    }
	
	    public override TResult Accept<TResult>(CalculatorSyntaxVisitor<TResult> visitor)
	    {
	        return visitor.Visit(this);
	    }
	
	    public override void Accept(CalculatorSyntaxVisitor visitor)
	    {
	        visitor.Visit(this);
	    }
	}
	
	public class ValueExpressionSyntax : ExpressionSyntax
	{
	    private ValueSyntax value;
	
	    public ValueExpressionSyntax(GreenNode green, SyntaxNode parent, int position)
	        : base(green, parent, position)
	    {
	    }
	
	    public ValueSyntax Value 
		{ 
			get
			{
				return this.GetRed(ref this.value, 0);
			} 
		}
	
	    public override SyntaxNode GetSlot(int index)
	    {
	        switch (index)
	        {
				case 0: return this.GetRed(ref this.value, 0);
				default: return null;
	        }
	    }
	
	    public override SyntaxNode GetCachedSlot(int index)
	    {
	        switch (index)
	        {
				case 0: return this.value;
				default: return null;
	        }
	    }
	
	    public override SyntaxNode WithAnnotations(ImmutableList<SyntaxAnnotation> annotations)
	    {
	        return this.Green.WithAnnotations(annotations).CreateRed();
	    }
	
	    public ValueExpressionSyntax WithValue(ValueSyntax value)
		{
			return this.Update(Value);
		}
	
	    public ValueExpressionSyntax Update(ValueSyntax value)
	    {
	        if (this.Value != value)
	        {
	            SyntaxNode newNode = CalculatorSyntaxFactory.ValueExpression(value);
	            var annotations = this.Annotations;
	            if (annotations != null && annotations.Count > 0)
	               newNode = newNode.WithAnnotations(annotations);
				return (ValueExpressionSyntax)newNode;
	        }
	        return this;
	    }
	
	    public override TResult Accept<TResult>(CalculatorSyntaxVisitor<TResult> visitor)
	    {
	        return visitor.Visit(this);
	    }
	
	    public override void Accept(CalculatorSyntaxVisitor visitor)
	    {
	        visitor.Visit(this);
	    }
	}
	
	public class ArgsSyntax : CalculatorSyntaxNode
	{
	    private SyntaxNode arg;
	
	    public ArgsSyntax(GreenNode green, SyntaxNode parent, int position)
	        : base(green, parent, position)
	    {
	    }
	
	    public SyntaxListNode<ArgSyntax> Arg 
		{ 
			get
			{
				var red = this.GetRed(ref this.arg, 0);
				if (red != null)
				{
					return new SyntaxListNode<ArgSyntax>(red);
				}
				return null;
			} 
		}
	    public SyntaxToken TComma { get { return new SyntaxToken(((global::MetaDslx.Languages.Calculator.Syntax.InternalSyntax.ArgsGreen)this.Green).TComma, this, this.GetChildPosition(1), this.GetChildIndex(1)); } }
	
	    public override SyntaxNode GetSlot(int index)
	    {
	        switch (index)
	        {
				case 0: return this.GetRed(ref this.arg, 0);
				default: return null;
	        }
	    }
	
	    public override SyntaxNode GetCachedSlot(int index)
	    {
	        switch (index)
	        {
				case 0: return this.arg;
				default: return null;
	        }
	    }
	
	    public override SyntaxNode WithAnnotations(ImmutableList<SyntaxAnnotation> annotations)
	    {
	        return this.Green.WithAnnotations(annotations).CreateRed();
	    }
	
	    public ArgsSyntax WithArg(SyntaxListNode<ArgSyntax> arg)
		{
			return this.Update(Arg, this.TComma);
		}
	
	    public ArgsSyntax AddArg(params ArgSyntax[] arg)
		{
			return this.WithArg(this.Arg.AddRange(arg));
		}
	
	    public ArgsSyntax WithTComma(SyntaxToken tComma)
		{
			return this.Update(this.Arg, TComma);
		}
	
	    public ArgsSyntax Update(SyntaxListNode<ArgSyntax> arg, SyntaxToken tComma)
	    {
	        if (this.Arg != arg ||
				this.TComma != tComma)
	        {
	            SyntaxNode newNode = CalculatorSyntaxFactory.Args(arg, tComma);
	            var annotations = this.Annotations;
	            if (annotations != null && annotations.Count > 0)
	               newNode = newNode.WithAnnotations(annotations);
				return (ArgsSyntax)newNode;
	        }
	        return this;
	    }
	
	    public override TResult Accept<TResult>(CalculatorSyntaxVisitor<TResult> visitor)
	    {
	        return visitor.Visit(this);
	    }
	
	    public override void Accept(CalculatorSyntaxVisitor visitor)
	    {
	        visitor.Visit(this);
	    }
	}
	
	public class ValueSyntax : CalculatorSyntaxNode
	{
	    private IdentifierSyntax identifier;
	    private StringSyntax _string;
	    private IntegerSyntax integer;
	
	    public ValueSyntax(GreenNode green, SyntaxNode parent, int position)
	        : base(green, parent, position)
	    {
	    }
	
	    public IdentifierSyntax Identifier 
		{ 
			get
			{
				return this.GetRed(ref this.identifier, 0);
			} 
		}
	    public StringSyntax String 
		{ 
			get
			{
				return this.GetRed(ref this._string, 1);
			} 
		}
	    public IntegerSyntax Integer 
		{ 
			get
			{
				return this.GetRed(ref this.integer, 2);
			} 
		}
	
	    public override SyntaxNode GetSlot(int index)
	    {
	        switch (index)
	        {
				case 0: return this.GetRed(ref this.identifier, 0);
				case 1: return this.GetRed(ref this._string, 1);
				case 2: return this.GetRed(ref this.integer, 2);
				default: return null;
	        }
	    }
	
	    public override SyntaxNode GetCachedSlot(int index)
	    {
	        switch (index)
	        {
				case 0: return this.identifier;
				case 1: return this._string;
				case 2: return this.integer;
				default: return null;
	        }
	    }
	
	    public override SyntaxNode WithAnnotations(ImmutableList<SyntaxAnnotation> annotations)
	    {
	        return this.Green.WithAnnotations(annotations).CreateRed();
	    }
	
	    public ValueSyntax WithIdentifier(IdentifierSyntax identifier)
		{
			return this.Update(Identifier, this.String, this.Integer);
		}
	
	    public ValueSyntax WithString(StringSyntax _string)
		{
			return this.Update(this.Identifier, String, this.Integer);
		}
	
	    public ValueSyntax WithInteger(IntegerSyntax integer)
		{
			return this.Update(this.Identifier, this.String, Integer);
		}
	
	    public ValueSyntax Update(IdentifierSyntax identifier, StringSyntax _string, IntegerSyntax integer)
	    {
	        if (this.Identifier != identifier ||
				this.String != _string ||
				this.Integer != integer)
	        {
	            SyntaxNode newNode = CalculatorSyntaxFactory.Value(identifier, _string, integer);
	            var annotations = this.Annotations;
	            if (annotations != null && annotations.Count > 0)
	               newNode = newNode.WithAnnotations(annotations);
				return (ValueSyntax)newNode;
	        }
	        return this;
	    }
	
	    public override TResult Accept<TResult>(CalculatorSyntaxVisitor<TResult> visitor)
	    {
	        return visitor.Visit(this);
	    }
	
	    public override void Accept(CalculatorSyntaxVisitor visitor)
	    {
	        visitor.Visit(this);
	    }
	}
	
	public class IdentifierSyntax : CalculatorSyntaxNode
	{
	
	    public IdentifierSyntax(GreenNode green, SyntaxNode parent, int position)
	        : base(green, parent, position)
	    {
	    }
	
	    public SyntaxToken ID { get { return new SyntaxToken(((global::MetaDslx.Languages.Calculator.Syntax.InternalSyntax.IdentifierGreen)this.Green).ID, this, this.GetChildPosition(0), this.GetChildIndex(0)); } }
	
	    public override SyntaxNode GetSlot(int index)
	    {
	        switch (index)
	        {
				default: return null;
	        }
	    }
	
	    public override SyntaxNode GetCachedSlot(int index)
	    {
	        switch (index)
	        {
				default: return null;
	        }
	    }
	
	    public override SyntaxNode WithAnnotations(ImmutableList<SyntaxAnnotation> annotations)
	    {
	        return this.Green.WithAnnotations(annotations).CreateRed();
	    }
	
	    public IdentifierSyntax WithID(SyntaxToken iD)
		{
			return this.Update(ID);
		}
	
	    public IdentifierSyntax Update(SyntaxToken iD)
	    {
	        if (this.ID != iD)
	        {
	            SyntaxNode newNode = CalculatorSyntaxFactory.Identifier(iD);
	            var annotations = this.Annotations;
	            if (annotations != null && annotations.Count > 0)
	               newNode = newNode.WithAnnotations(annotations);
				return (IdentifierSyntax)newNode;
	        }
	        return this;
	    }
	
	    public override TResult Accept<TResult>(CalculatorSyntaxVisitor<TResult> visitor)
	    {
	        return visitor.Visit(this);
	    }
	
	    public override void Accept(CalculatorSyntaxVisitor visitor)
	    {
	        visitor.Visit(this);
	    }
	}
	
	public class StringSyntax : CalculatorSyntaxNode
	{
	
	    public StringSyntax(GreenNode green, SyntaxNode parent, int position)
	        : base(green, parent, position)
	    {
	    }
	
	    public SyntaxToken STRING { get { return new SyntaxToken(((global::MetaDslx.Languages.Calculator.Syntax.InternalSyntax.StringGreen)this.Green).STRING, this, this.GetChildPosition(0), this.GetChildIndex(0)); } }
	
	    public override SyntaxNode GetSlot(int index)
	    {
	        switch (index)
	        {
				default: return null;
	        }
	    }
	
	    public override SyntaxNode GetCachedSlot(int index)
	    {
	        switch (index)
	        {
				default: return null;
	        }
	    }
	
	    public override SyntaxNode WithAnnotations(ImmutableList<SyntaxAnnotation> annotations)
	    {
	        return this.Green.WithAnnotations(annotations).CreateRed();
	    }
	
	    public StringSyntax WithSTRING(SyntaxToken sTRING)
		{
			return this.Update(STRING);
		}
	
	    public StringSyntax Update(SyntaxToken sTRING)
	    {
	        if (this.STRING != sTRING)
	        {
	            SyntaxNode newNode = CalculatorSyntaxFactory.String(sTRING);
	            var annotations = this.Annotations;
	            if (annotations != null && annotations.Count > 0)
	               newNode = newNode.WithAnnotations(annotations);
				return (StringSyntax)newNode;
	        }
	        return this;
	    }
	
	    public override TResult Accept<TResult>(CalculatorSyntaxVisitor<TResult> visitor)
	    {
	        return visitor.Visit(this);
	    }
	
	    public override void Accept(CalculatorSyntaxVisitor visitor)
	    {
	        visitor.Visit(this);
	    }
	}
	
	public class IntegerSyntax : CalculatorSyntaxNode
	{
	
	    public IntegerSyntax(GreenNode green, SyntaxNode parent, int position)
	        : base(green, parent, position)
	    {
	    }
	
	    public SyntaxToken INT { get { return new SyntaxToken(((global::MetaDslx.Languages.Calculator.Syntax.InternalSyntax.IntegerGreen)this.Green).INT, this, this.GetChildPosition(0), this.GetChildIndex(0)); } }
	
	    public override SyntaxNode GetSlot(int index)
	    {
	        switch (index)
	        {
				default: return null;
	        }
	    }
	
	    public override SyntaxNode GetCachedSlot(int index)
	    {
	        switch (index)
	        {
				default: return null;
	        }
	    }
	
	    public override SyntaxNode WithAnnotations(ImmutableList<SyntaxAnnotation> annotations)
	    {
	        return this.Green.WithAnnotations(annotations).CreateRed();
	    }
	
	    public IntegerSyntax WithINT(SyntaxToken iNT)
		{
			return this.Update(INT);
		}
	
	    public IntegerSyntax Update(SyntaxToken iNT)
	    {
	        if (this.INT != iNT)
	        {
	            SyntaxNode newNode = CalculatorSyntaxFactory.Integer(iNT);
	            var annotations = this.Annotations;
	            if (annotations != null && annotations.Count > 0)
	               newNode = newNode.WithAnnotations(annotations);
				return (IntegerSyntax)newNode;
	        }
	        return this;
	    }
	
	    public override TResult Accept<TResult>(CalculatorSyntaxVisitor<TResult> visitor)
	    {
	        return visitor.Visit(this);
	    }
	
	    public override void Accept(CalculatorSyntaxVisitor visitor)
	    {
	        visitor.Visit(this);
	    }
	}
	
	public class ArgSyntax : CalculatorSyntaxNode
	{
	    private ValueSyntax value;
	
	    public ArgSyntax(GreenNode green, SyntaxNode parent, int position)
	        : base(green, parent, position)
	    {
	    }
	
	    public ValueSyntax Value 
		{ 
			get
			{
				return this.GetRed(ref this.value, 0);
			} 
		}
	
	    public override SyntaxNode GetSlot(int index)
	    {
	        switch (index)
	        {
				case 0: return this.GetRed(ref this.value, 0);
				default: return null;
	        }
	    }
	
	    public override SyntaxNode GetCachedSlot(int index)
	    {
	        switch (index)
	        {
				case 0: return this.value;
				default: return null;
	        }
	    }
	
	    public override SyntaxNode WithAnnotations(ImmutableList<SyntaxAnnotation> annotations)
	    {
	        return this.Green.WithAnnotations(annotations).CreateRed();
	    }
	
	    public ArgSyntax WithValue(ValueSyntax value)
		{
			return this.Update(Value);
		}
	
	    public ArgSyntax Update(ValueSyntax value)
	    {
	        if (this.Value != value)
	        {
	            SyntaxNode newNode = CalculatorSyntaxFactory.Arg(value);
	            var annotations = this.Annotations;
	            if (annotations != null && annotations.Count > 0)
	               newNode = newNode.WithAnnotations(annotations);
				return (ArgSyntax)newNode;
	        }
	        return this;
	    }
	
	    public override TResult Accept<TResult>(CalculatorSyntaxVisitor<TResult> visitor)
	    {
	        return visitor.Visit(this);
	    }
	
	    public override void Accept(CalculatorSyntaxVisitor visitor)
	    {
	        visitor.Visit(this);
	    }
	}
}

namespace MetaDslx.Languages.Calculator
{
	using MetaDslx.Languages.Calculator.Syntax;

	
	public static class CalculatorSyntaxFacts
	{
		public static string GetText(CalculatorSyntaxKind kind)
	    {
			switch (kind)
	        {
				case CalculatorSyntaxKind.TSemicolon:
					return ";";
				case CalculatorSyntaxKind.TOpenParen:
					return "(";
				case CalculatorSyntaxKind.TCloseParen:
					return ")";
				case CalculatorSyntaxKind.TComma:
					return ",";
				case CalculatorSyntaxKind.TAssign:
					return "=";
				case CalculatorSyntaxKind.TAdd:
					return "+";
				case CalculatorSyntaxKind.TSub:
					return "-";
				case CalculatorSyntaxKind.TMul:
					return "*";
				case CalculatorSyntaxKind.TDiv:
					return "/";
				case CalculatorSyntaxKind.KPrint:
					return "print";
				default:
					return string.Empty;
			}
		}
	
		public static CalculatorSyntaxKind GetKind(string text)
	    {
			switch (text)
	        {
				case ";":
					return CalculatorSyntaxKind.TSemicolon;
				case "(":
					return CalculatorSyntaxKind.TOpenParen;
				case ")":
					return CalculatorSyntaxKind.TCloseParen;
				case ",":
					return CalculatorSyntaxKind.TComma;
				case "=":
					return CalculatorSyntaxKind.TAssign;
				case "+":
					return CalculatorSyntaxKind.TAdd;
				case "-":
					return CalculatorSyntaxKind.TSub;
				case "*":
					return CalculatorSyntaxKind.TMul;
				case "/":
					return CalculatorSyntaxKind.TDiv;
				case "print":
					return CalculatorSyntaxKind.KPrint;
				default:
					return CalculatorSyntaxKind.None;
			}
		}
	}

	public class CalculatorSyntaxVisitor : SyntaxVisitor
	{
	    public virtual void Visit(CalculatorSyntaxNode node)
	    {
	        node.Accept(this);
	    }
	
	    public virtual void Visit(CalculatorSyntaxTrivia node)
	    {
	        node.Accept(this);
	    }
		
		public virtual void VisitMain(MainSyntax node)
		{
		    this.DefaultVisit(node);
		}
		
		public virtual void VisitStatementLine(StatementLineSyntax node)
		{
		    this.DefaultVisit(node);
		}
		
		public virtual void VisitStatement(StatementSyntax node)
		{
		    this.DefaultVisit(node);
		}
		
		public virtual void VisitAssignment(AssignmentSyntax node)
		{
		    this.DefaultVisit(node);
		}
		
		public virtual void VisitParenExpression(ParenExpressionSyntax node)
		{
		    this.DefaultVisit(node);
		}
		
		public virtual void VisitMulOrDivExpression(MulOrDivExpressionSyntax node)
		{
		    this.DefaultVisit(node);
		}
		
		public virtual void VisitAddOrSubExpression(AddOrSubExpressionSyntax node)
		{
		    this.DefaultVisit(node);
		}
		
		public virtual void VisitPrintExpression(PrintExpressionSyntax node)
		{
		    this.DefaultVisit(node);
		}
		
		public virtual void VisitValueExpression(ValueExpressionSyntax node)
		{
		    this.DefaultVisit(node);
		}
		
		public virtual void VisitArgs(ArgsSyntax node)
		{
		    this.DefaultVisit(node);
		}
		
		public virtual void VisitValue(ValueSyntax node)
		{
		    this.DefaultVisit(node);
		}
		
		public virtual void VisitIdentifier(IdentifierSyntax node)
		{
		    this.DefaultVisit(node);
		}
		
		public virtual void VisitString(StringSyntax node)
		{
		    this.DefaultVisit(node);
		}
		
		public virtual void VisitInteger(IntegerSyntax node)
		{
		    this.DefaultVisit(node);
		}
		
		public virtual void VisitArg(ArgSyntax node)
		{
		    this.DefaultVisit(node);
		}
	}

	public class CalculatorSyntaxVisitor<TResult> : SyntaxVisitor<TResult>
	{
	    public virtual TResult Visit(CalculatorSyntaxNode node)
	    {
	        return node.Accept(this);
	    }
	
	    public virtual TResult Visit(CalculatorSyntaxTrivia node)
	    {
	        return node.Accept(this);
	    }
		
		public virtual TResult VisitMain(MainSyntax node)
		{
		    return this.DefaultVisit(node);
		}
		
		public virtual TResult VisitStatementLine(StatementLineSyntax node)
		{
		    return this.DefaultVisit(node);
		}
		
		public virtual TResult VisitStatement(StatementSyntax node)
		{
		    return this.DefaultVisit(node);
		}
		
		public virtual TResult VisitAssignment(AssignmentSyntax node)
		{
		    return this.DefaultVisit(node);
		}
		
		public virtual TResult VisitParenExpression(ParenExpressionSyntax node)
		{
		    return this.DefaultVisit(node);
		}
		
		public virtual TResult VisitMulOrDivExpression(MulOrDivExpressionSyntax node)
		{
		    return this.DefaultVisit(node);
		}
		
		public virtual TResult VisitAddOrSubExpression(AddOrSubExpressionSyntax node)
		{
		    return this.DefaultVisit(node);
		}
		
		public virtual TResult VisitPrintExpression(PrintExpressionSyntax node)
		{
		    return this.DefaultVisit(node);
		}
		
		public virtual TResult VisitValueExpression(ValueExpressionSyntax node)
		{
		    return this.DefaultVisit(node);
		}
		
		public virtual TResult VisitArgs(ArgsSyntax node)
		{
		    return this.DefaultVisit(node);
		}
		
		public virtual TResult VisitValue(ValueSyntax node)
		{
		    return this.DefaultVisit(node);
		}
		
		public virtual TResult VisitIdentifier(IdentifierSyntax node)
		{
		    return this.DefaultVisit(node);
		}
		
		public virtual TResult VisitString(StringSyntax node)
		{
		    return this.DefaultVisit(node);
		}
		
		public virtual TResult VisitInteger(IntegerSyntax node)
		{
		    return this.DefaultVisit(node);
		}
		
		public virtual TResult VisitArg(ArgSyntax node)
		{
		    return this.DefaultVisit(node);
		}
	}

	public class CalculatorSyntaxRewriter : CalculatorSyntaxVisitor<SyntaxNode>
	{
	    protected readonly bool VisitIntoStructuredTrivia;
	
	    public CalculatorSyntaxRewriter(bool visitIntoStructuredTrivia = false)
	    {
	        this.VisitIntoStructuredTrivia = visitIntoStructuredTrivia;
	    }
	
	    public override SyntaxToken VisitToken(SyntaxToken token)
	    {
			// TODO
	        throw new NotImplementedException();
	    }
	
	    public SyntaxListNode<TNode> VisitList<TNode>(SyntaxListNode<TNode> list) where TNode : SyntaxNode
	    {
			// TODO
	        throw new NotImplementedException();
	    }
	
	    public SeparatedSyntaxList<TNode> VisitList<TNode>(SeparatedSyntaxList<TNode> list) where TNode : SyntaxNode
	    {
			// TODO
	        throw new NotImplementedException();
	    }
		
		public override SyntaxNode VisitMain(MainSyntax node)
		{
		    var statementLine = (StatementLineSyntax)this.Visit(node.StatementLine);
		    var endOfFileToken = this.VisitToken(node.EndOfFileToken);
			return node.Update(statementLine, endOfFileToken);
		}
		
		public override SyntaxNode VisitStatementLine(StatementLineSyntax node)
		{
		    var statement = (StatementSyntax)this.Visit(node.Statement);
		    var tSemicolon = this.VisitToken(node.TSemicolon);
			return node.Update(statement, tSemicolon);
		}
		
		public override SyntaxNode VisitStatement(StatementSyntax node)
		{
		    var assignment = (AssignmentSyntax)this.Visit(node.Assignment);
		    var expression = (ExpressionSyntax)this.Visit(node.Expression);
			return node.Update(assignment, expression);
		}
		
		public override SyntaxNode VisitAssignment(AssignmentSyntax node)
		{
		    var identifier = (IdentifierSyntax)this.Visit(node.Identifier);
		    var tAssign = this.VisitToken(node.TAssign);
		    var expression = (ExpressionSyntax)this.Visit(node.Expression);
			return node.Update(identifier, tAssign, expression);
		}
		
		public override SyntaxNode VisitParenExpression(ParenExpressionSyntax node)
		{
		    var tOpenParen = this.VisitToken(node.TOpenParen);
		    var expression = (ExpressionSyntax)this.Visit(node.Expression);
		    var tCloseParen = this.VisitToken(node.TCloseParen);
			return node.Update(tOpenParen, expression, tCloseParen);
		}
		
		public override SyntaxNode VisitMulOrDivExpression(MulOrDivExpressionSyntax node)
		{
		    var left = (ExpressionSyntax)this.Visit(node.Left);
		    var tMul = this.VisitToken(node.TMul);
		    var tDiv = this.VisitToken(node.TDiv);
		    var right = (ExpressionSyntax)this.Visit(node.Right);
			return node.Update(left, tMul, tDiv, right);
		}
		
		public override SyntaxNode VisitAddOrSubExpression(AddOrSubExpressionSyntax node)
		{
		    var left = (ExpressionSyntax)this.Visit(node.Left);
		    var tAdd = this.VisitToken(node.TAdd);
		    var tSub = this.VisitToken(node.TSub);
		    var right = (ExpressionSyntax)this.Visit(node.Right);
			return node.Update(left, tAdd, tSub, right);
		}
		
		public override SyntaxNode VisitPrintExpression(PrintExpressionSyntax node)
		{
		    var kPrint = this.VisitToken(node.KPrint);
		    var args = (ArgsSyntax)this.Visit(node.Args);
			return node.Update(kPrint, args);
		}
		
		public override SyntaxNode VisitValueExpression(ValueExpressionSyntax node)
		{
		    var value = (ValueSyntax)this.Visit(node.Value);
			return node.Update(value);
		}
		
		public override SyntaxNode VisitArgs(ArgsSyntax node)
		{
		    var arg = this.VisitList<ArgSyntax>(node.Arg);
		    var tComma = this.VisitToken(node.TComma);
			return node.Update(arg, tComma);
		}
		
		public override SyntaxNode VisitValue(ValueSyntax node)
		{
		    var identifier = (IdentifierSyntax)this.Visit(node.Identifier);
		    var _string = (StringSyntax)this.Visit(node.String);
		    var integer = (IntegerSyntax)this.Visit(node.Integer);
			return node.Update(identifier, _string, integer);
		}
		
		public override SyntaxNode VisitIdentifier(IdentifierSyntax node)
		{
		    var iD = this.VisitToken(node.ID);
			return node.Update(iD);
		}
		
		public override SyntaxNode VisitString(StringSyntax node)
		{
		    var sTRING = this.VisitToken(node.STRING);
			return node.Update(sTRING);
		}
		
		public override SyntaxNode VisitInteger(IntegerSyntax node)
		{
		    var iNT = this.VisitToken(node.INT);
			return node.Update(iNT);
		}
		
		public override SyntaxNode VisitArg(ArgSyntax node)
		{
		    var value = (ValueSyntax)this.Visit(node.Value);
			return node.Update(value);
		}
	}

	public class CalculatorSyntaxFactory : SyntaxFactory
	{
	    /// <summary>
	    /// Creates a token corresponding to a syntax kind. This method can be used for token syntax kinds whose text
	    /// can be inferred by the kind alone.
	    /// </summary>
	    /// <param name="kind">A syntax kind value for a token. These have the suffix Token or Keyword.</param>
	    /// <returns></returns>
	    public static SyntaxToken Token(CalculatorSyntaxKind kind)
	    {
	        return new SyntaxToken(Syntax.InternalSyntax.CalculatorGreenFactory.Token(kind));
	    }
	
	    public static SyntaxToken STRING(string text)
	    {
	        return new SyntaxToken(Syntax.InternalSyntax.CalculatorGreenFactory.STRING(text));
	    }
	
	    public static SyntaxToken STRING(string text, object value)
	    {
	        return new SyntaxToken(Syntax.InternalSyntax.CalculatorGreenFactory.STRING(text, value));
	    }
	
	    public static SyntaxToken ID(string text)
	    {
	        return new SyntaxToken(Syntax.InternalSyntax.CalculatorGreenFactory.ID(text));
	    }
	
	    public static SyntaxToken ID(string text, object value)
	    {
	        return new SyntaxToken(Syntax.InternalSyntax.CalculatorGreenFactory.ID(text, value));
	    }
	
	    public static SyntaxToken INT(string text)
	    {
	        return new SyntaxToken(Syntax.InternalSyntax.CalculatorGreenFactory.INT(text));
	    }
	
	    public static SyntaxToken INT(string text, object value)
	    {
	        return new SyntaxToken(Syntax.InternalSyntax.CalculatorGreenFactory.INT(text, value));
	    }
	
	    public static SyntaxToken UTF8BOM(string text)
	    {
	        return new SyntaxToken(Syntax.InternalSyntax.CalculatorGreenFactory.UTF8BOM(text));
	    }
	
	    public static SyntaxToken UTF8BOM(string text, object value)
	    {
	        return new SyntaxToken(Syntax.InternalSyntax.CalculatorGreenFactory.UTF8BOM(text, value));
	    }
	
	    public static SyntaxToken WHITESPACE(string text)
	    {
	        return new SyntaxToken(Syntax.InternalSyntax.CalculatorGreenFactory.WHITESPACE(text));
	    }
	
	    public static SyntaxToken WHITESPACE(string text, object value)
	    {
	        return new SyntaxToken(Syntax.InternalSyntax.CalculatorGreenFactory.WHITESPACE(text, value));
	    }
	
	    public static SyntaxToken ENDL(string text)
	    {
	        return new SyntaxToken(Syntax.InternalSyntax.CalculatorGreenFactory.ENDL(text));
	    }
	
	    public static SyntaxToken ENDL(string text, object value)
	    {
	        return new SyntaxToken(Syntax.InternalSyntax.CalculatorGreenFactory.ENDL(text, value));
	    }
	
	    public static SyntaxToken COMMENT(string text)
	    {
	        return new SyntaxToken(Syntax.InternalSyntax.CalculatorGreenFactory.COMMENT(text));
	    }
	
	    public static SyntaxToken COMMENT(string text, object value)
	    {
	        return new SyntaxToken(Syntax.InternalSyntax.CalculatorGreenFactory.COMMENT(text, value));
	    }
		
		public static MainSyntax Main(StatementLineSyntax statementLine, SyntaxToken endOfFileToken)
		{
		    if (statementLine == null) throw new ArgumentNullException(nameof(statementLine));
		    if (endOfFileToken == null) throw new ArgumentNullException(nameof(endOfFileToken));
		    if (endOfFileToken.RawKind != (int)CalculatorSyntaxKind.EOF) throw new ArgumentException(nameof(endOfFileToken));
		    return (MainSyntax)Syntax.InternalSyntax.CalculatorGreenFactory.Main((Syntax.InternalSyntax.StatementLineGreen)statementLine.Green, (global::MetaDslx.Compiler.Core.Syntax.InternalSyntaxToken)endOfFileToken.Green).CreateRed();
		}
		
		public static StatementLineSyntax StatementLine(StatementSyntax statement, SyntaxToken tSemicolon)
		{
		    if (statement == null) throw new ArgumentNullException(nameof(statement));
		    if (tSemicolon == null) throw new ArgumentNullException(nameof(tSemicolon));
		    if (tSemicolon.RawKind != (int)CalculatorSyntaxKind.TSemicolon) throw new ArgumentException(nameof(tSemicolon));
		    return (StatementLineSyntax)Syntax.InternalSyntax.CalculatorGreenFactory.StatementLine((Syntax.InternalSyntax.StatementGreen)statement.Green, (global::MetaDslx.Compiler.Core.Syntax.InternalSyntaxToken)tSemicolon.Green).CreateRed();
		}
		
		public static StatementLineSyntax StatementLine(StatementSyntax statement)
		{
			return CalculatorSyntaxFactory.StatementLine(statement, CalculatorSyntaxFactory.Token(CalculatorSyntaxKind.TSemicolon));
		}
		
		public static StatementSyntax Statement(AssignmentSyntax assignment, ExpressionSyntax expression)
		{
		    return (StatementSyntax)Syntax.InternalSyntax.CalculatorGreenFactory.Statement(assignment == null ? null : (Syntax.InternalSyntax.AssignmentGreen)assignment.Green, expression == null ? null : (Syntax.InternalSyntax.ExpressionGreen)expression.Green).CreateRed();
		}
		
		public static StatementSyntax Statement()
		{
			return CalculatorSyntaxFactory.Statement(null, null);
		}
		
		public static AssignmentSyntax Assignment(IdentifierSyntax identifier, SyntaxToken tAssign, ExpressionSyntax expression)
		{
		    if (identifier == null) throw new ArgumentNullException(nameof(identifier));
		    if (tAssign == null) throw new ArgumentNullException(nameof(tAssign));
		    if (tAssign.RawKind != (int)CalculatorSyntaxKind.TAssign) throw new ArgumentException(nameof(tAssign));
		    if (expression == null) throw new ArgumentNullException(nameof(expression));
		    return (AssignmentSyntax)Syntax.InternalSyntax.CalculatorGreenFactory.Assignment((Syntax.InternalSyntax.IdentifierGreen)identifier.Green, (global::MetaDslx.Compiler.Core.Syntax.InternalSyntaxToken)tAssign.Green, (Syntax.InternalSyntax.ExpressionGreen)expression.Green).CreateRed();
		}
		
		public static AssignmentSyntax Assignment(IdentifierSyntax identifier, ExpressionSyntax expression)
		{
			return CalculatorSyntaxFactory.Assignment(identifier, CalculatorSyntaxFactory.Token(CalculatorSyntaxKind.TAssign), expression);
		}
		
		public static ParenExpressionSyntax ParenExpression(SyntaxToken tOpenParen, ExpressionSyntax expression, SyntaxToken tCloseParen)
		{
		    if (tOpenParen == null) throw new ArgumentNullException(nameof(tOpenParen));
		    if (tOpenParen.RawKind != (int)CalculatorSyntaxKind.TOpenParen) throw new ArgumentException(nameof(tOpenParen));
		    if (expression == null) throw new ArgumentNullException(nameof(expression));
		    if (tCloseParen == null) throw new ArgumentNullException(nameof(tCloseParen));
		    if (tCloseParen.RawKind != (int)CalculatorSyntaxKind.TCloseParen) throw new ArgumentException(nameof(tCloseParen));
		    return (ParenExpressionSyntax)Syntax.InternalSyntax.CalculatorGreenFactory.ParenExpression((global::MetaDslx.Compiler.Core.Syntax.InternalSyntaxToken)tOpenParen.Green, (Syntax.InternalSyntax.ExpressionGreen)expression.Green, (global::MetaDslx.Compiler.Core.Syntax.InternalSyntaxToken)tCloseParen.Green).CreateRed();
		}
		
		public static ParenExpressionSyntax ParenExpression(ExpressionSyntax expression)
		{
			return CalculatorSyntaxFactory.ParenExpression(CalculatorSyntaxFactory.Token(CalculatorSyntaxKind.TOpenParen), expression, CalculatorSyntaxFactory.Token(CalculatorSyntaxKind.TCloseParen));
		}
		
		public static MulOrDivExpressionSyntax MulOrDivExpression(ExpressionSyntax left, SyntaxToken tMul, SyntaxToken tDiv, ExpressionSyntax right)
		{
		    if (left == null) throw new ArgumentNullException(nameof(left));
		    if (tMul != null && tMul.RawKind != (int)CalculatorSyntaxKind.TMul) throw new ArgumentException(nameof(tMul));
		    if (tDiv != null && tDiv.RawKind != (int)CalculatorSyntaxKind.TDiv) throw new ArgumentException(nameof(tDiv));
		    if (right == null) throw new ArgumentNullException(nameof(right));
		    return (MulOrDivExpressionSyntax)Syntax.InternalSyntax.CalculatorGreenFactory.MulOrDivExpression((Syntax.InternalSyntax.ExpressionGreen)left.Green, tMul == null ? null : (global::MetaDslx.Compiler.Core.Syntax.InternalSyntaxToken)tMul.Green, tDiv == null ? null : (global::MetaDslx.Compiler.Core.Syntax.InternalSyntaxToken)tDiv.Green, (Syntax.InternalSyntax.ExpressionGreen)right.Green).CreateRed();
		}
		
		public static MulOrDivExpressionSyntax MulOrDivExpression(ExpressionSyntax left, ExpressionSyntax right)
		{
			return CalculatorSyntaxFactory.MulOrDivExpression(left, null, null, right);
		}
		
		public static AddOrSubExpressionSyntax AddOrSubExpression(ExpressionSyntax left, SyntaxToken tAdd, SyntaxToken tSub, ExpressionSyntax right)
		{
		    if (left == null) throw new ArgumentNullException(nameof(left));
		    if (tAdd != null && tAdd.RawKind != (int)CalculatorSyntaxKind.TAdd) throw new ArgumentException(nameof(tAdd));
		    if (tSub != null && tSub.RawKind != (int)CalculatorSyntaxKind.TSub) throw new ArgumentException(nameof(tSub));
		    if (right == null) throw new ArgumentNullException(nameof(right));
		    return (AddOrSubExpressionSyntax)Syntax.InternalSyntax.CalculatorGreenFactory.AddOrSubExpression((Syntax.InternalSyntax.ExpressionGreen)left.Green, tAdd == null ? null : (global::MetaDslx.Compiler.Core.Syntax.InternalSyntaxToken)tAdd.Green, tSub == null ? null : (global::MetaDslx.Compiler.Core.Syntax.InternalSyntaxToken)tSub.Green, (Syntax.InternalSyntax.ExpressionGreen)right.Green).CreateRed();
		}
		
		public static AddOrSubExpressionSyntax AddOrSubExpression(ExpressionSyntax left, ExpressionSyntax right)
		{
			return CalculatorSyntaxFactory.AddOrSubExpression(left, null, null, right);
		}
		
		public static PrintExpressionSyntax PrintExpression(SyntaxToken kPrint, ArgsSyntax args)
		{
		    if (kPrint == null) throw new ArgumentNullException(nameof(kPrint));
		    if (kPrint.RawKind != (int)CalculatorSyntaxKind.KPrint) throw new ArgumentException(nameof(kPrint));
		    if (args == null) throw new ArgumentNullException(nameof(args));
		    return (PrintExpressionSyntax)Syntax.InternalSyntax.CalculatorGreenFactory.PrintExpression((global::MetaDslx.Compiler.Core.Syntax.InternalSyntaxToken)kPrint.Green, (Syntax.InternalSyntax.ArgsGreen)args.Green).CreateRed();
		}
		
		public static PrintExpressionSyntax PrintExpression(ArgsSyntax args)
		{
			return CalculatorSyntaxFactory.PrintExpression(CalculatorSyntaxFactory.Token(CalculatorSyntaxKind.KPrint), args);
		}
		
		public static ValueExpressionSyntax ValueExpression(ValueSyntax value)
		{
		    if (value == null) throw new ArgumentNullException(nameof(value));
		    return (ValueExpressionSyntax)Syntax.InternalSyntax.CalculatorGreenFactory.ValueExpression((Syntax.InternalSyntax.ValueGreen)value.Green).CreateRed();
		}
		
		public static ArgsSyntax Args(SyntaxListNode<ArgSyntax> arg, SyntaxToken tComma)
		{
		    if (arg == null) throw new ArgumentNullException(nameof(arg));
		    if (tComma == null) throw new ArgumentNullException(nameof(tComma));
		    if (tComma.RawKind != (int)CalculatorSyntaxKind.TComma) throw new ArgumentException(nameof(tComma));
		    return (ArgsSyntax)Syntax.InternalSyntax.CalculatorGreenFactory.Args(arg.Node.ToGreenList<Syntax.InternalSyntax.ArgGreen>(), (global::MetaDslx.Compiler.Core.Syntax.InternalSyntaxToken)tComma.Green).CreateRed();
		}
		
		public static ArgsSyntax Args(SyntaxListNode<ArgSyntax> arg)
		{
			return CalculatorSyntaxFactory.Args(arg, CalculatorSyntaxFactory.Token(CalculatorSyntaxKind.TComma));
		}
		
		public static ValueSyntax Value(IdentifierSyntax identifier, StringSyntax _string, IntegerSyntax integer)
		{
		    return (ValueSyntax)Syntax.InternalSyntax.CalculatorGreenFactory.Value(identifier == null ? null : (Syntax.InternalSyntax.IdentifierGreen)identifier.Green, _string == null ? null : (Syntax.InternalSyntax.StringGreen)_string.Green, integer == null ? null : (Syntax.InternalSyntax.IntegerGreen)integer.Green).CreateRed();
		}
		
		public static ValueSyntax Value()
		{
			return CalculatorSyntaxFactory.Value(null, null, null);
		}
		
		public static IdentifierSyntax Identifier(SyntaxToken iD)
		{
		    if (iD == null) throw new ArgumentNullException(nameof(iD));
		    if (iD.RawKind != (int)CalculatorSyntaxKind.ID) throw new ArgumentException(nameof(iD));
		    return (IdentifierSyntax)Syntax.InternalSyntax.CalculatorGreenFactory.Identifier((global::MetaDslx.Compiler.Core.Syntax.InternalSyntaxToken)iD.Green).CreateRed();
		}
		
		public static StringSyntax String(SyntaxToken sTRING)
		{
		    if (sTRING == null) throw new ArgumentNullException(nameof(sTRING));
		    if (sTRING.RawKind != (int)CalculatorSyntaxKind.STRING) throw new ArgumentException(nameof(sTRING));
		    return (StringSyntax)Syntax.InternalSyntax.CalculatorGreenFactory.String((global::MetaDslx.Compiler.Core.Syntax.InternalSyntaxToken)sTRING.Green).CreateRed();
		}
		
		public static IntegerSyntax Integer(SyntaxToken iNT)
		{
		    if (iNT == null) throw new ArgumentNullException(nameof(iNT));
		    if (iNT.RawKind != (int)CalculatorSyntaxKind.INT) throw new ArgumentException(nameof(iNT));
		    return (IntegerSyntax)Syntax.InternalSyntax.CalculatorGreenFactory.Integer((global::MetaDslx.Compiler.Core.Syntax.InternalSyntaxToken)iNT.Green).CreateRed();
		}
		
		public static ArgSyntax Arg(ValueSyntax value)
		{
		    if (value == null) throw new ArgumentNullException(nameof(value));
		    return (ArgSyntax)Syntax.InternalSyntax.CalculatorGreenFactory.Arg((Syntax.InternalSyntax.ValueGreen)value.Green).CreateRed();
		}
	
	    internal static IEnumerable<Type> GetNodeTypes()
	    {
	        return new Type[] {
				typeof(MainSyntax),
				typeof(StatementLineSyntax),
				typeof(StatementSyntax),
				typeof(AssignmentSyntax),
				typeof(ParenExpressionSyntax),
				typeof(MulOrDivExpressionSyntax),
				typeof(AddOrSubExpressionSyntax),
				typeof(PrintExpressionSyntax),
				typeof(ValueExpressionSyntax),
				typeof(ArgsSyntax),
				typeof(ValueSyntax),
				typeof(IdentifierSyntax),
				typeof(StringSyntax),
				typeof(IntegerSyntax),
				typeof(ArgSyntax),
			};
		}
	}
}

